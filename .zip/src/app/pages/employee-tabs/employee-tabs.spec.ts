import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeTabs } from './employee-tabs';

describe('EmployeeTabs', () => {
  let component: EmployeeTabs;
  let fixture: ComponentFixture<EmployeeTabs>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmployeeTabs]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeTabs);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
