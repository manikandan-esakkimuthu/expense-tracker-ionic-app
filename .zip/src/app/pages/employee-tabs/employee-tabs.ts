import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { IonTabBar, IonTabs, IonIcon, IonTabButton, IonLabel } from "@ionic/angular/standalone";
import { addIcons } from 'ionicons';
import { clipboardOutline, logOutOutline, notifications, notificationsOutline, personCircleOutline, speedometerOutline } from 'ionicons/icons';
@Component({
  selector: 'app-employee-tabs',
  imports: [IonTabBar, IonTabs, IonIcon, IonTabButton, IonLabel],
  templateUrl: './employee-tabs.html',
  styleUrl: './employee-tabs.scss'
})
export class EmployeeTabs {
  constructor(private router: Router, private alertCtrl: AlertController) {
    addIcons({ speedometerOutline, clipboardOutline, notificationsOutline, personCircleOutline, logOutOutline });
  }
  async logout() {
    const alert = await this.alertCtrl.create({
      header: 'Logout',
      message: 'Are you sure you want to log out?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
        },
        {
          text: 'Yes, Logout',
          handler: () => {
            // 🔹 Clear stored session/token
            localStorage.clear();
            // 🔹 Navigate to login page
            this.router.navigateByUrl('/login', { replaceUrl: true });
          },
        },
      ],
    });
    await alert.present();
  }
}
