import { Component } from '@angular/core';

@Component({
  selector: 'app-add-income',
  imports: [],
  templateUrl: './add-income.html',
  styleUrl: './add-income.scss'
})
export class AddIncome {

}
