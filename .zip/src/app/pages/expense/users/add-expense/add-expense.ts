import { Component } from '@angular/core';

@Component({
  selector: 'app-add-expense',
  imports: [],
  templateUrl: './add-expense.html',
  styleUrl: './add-expense.scss'
})
export class AddExpense {

}
