import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, IonicModule } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { cardOutline, walletOutline } from 'ionicons/icons';

@Component({
  selector: 'app-expenses',
  imports: [IonicModule, CommonModule],
  templateUrl: './expenses.html',
  styleUrl: './expenses.scss'
})
export class Expenses {
  constructor(private navCtrl: NavController, private router: Router) {
    addIcons({ walletOutline, cardOutline });
  }

  transactions = [
    { title: 'Sallary', date: '30 Apr 2022', icon: 'assets/img/salary.png', amount: 1500 },
    { title: 'Paypal', date: '28 Apr 2022', icon: 'assets/img/paypal.png', amount: 3500 },
    { title: 'Food', date: '25 Apr 2022', icon: 'assets/img/food.png', amount: -300 },
    { title: 'Upwork', date: '23 Apr 2022', icon: 'assets/img/upwork.png', amount: 800 },
    { title: 'Bill', date: '22 Apr 2022', icon: 'assets/img/bill.png', amount: -600 },
    { title: 'Discount', date: '20 Apr 2022', icon: 'assets/img/discount.png', amount: 200 },
  ];

  addIncome() {
    this.router.navigate(['/add-expense']);
  }
  addExpense() {
    // navigate to Add Expense form screen (future step)
    console.log('Navigate to Add Expense screen');
  }
}
