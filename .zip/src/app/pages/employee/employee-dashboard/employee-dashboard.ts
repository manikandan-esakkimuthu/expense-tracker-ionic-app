import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonCard, IonIcon, IonContent } from "@ionic/angular/standalone";
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);
import { addIcons } from 'ionicons';
import { briefcaseOutline, cashOutline, checkmarkDoneCircleOutline, clipboardOutline, hourglassOutline, notifications, notificationsOutline, personCircleOutline, speedometerOutline } from 'ionicons/icons';
@Component({
  selector: 'app-employee-dashboard',
  imports: [IonCard, IonIcon, IonContent, CommonModule, FormsModule],
  templateUrl: './employee-dashboard.html',
  styleUrl: './employee-dashboard.scss'
})
export class EmployeeDashboard implements OnInit {
  employeeName = 'Manikandan'; // you can bind from login later

  ngOnInit() {
    this.loadProgressChart();
  }
  constructor() {
    addIcons({ briefcaseOutline, checkmarkDoneCircleOutline, cashOutline, hourglassOutline });
  }
  loadProgressChart() {
    const ctx = document.getElementById('progressChart') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Completed', 'Pending'],
        datasets: [
          {
            data: [75, 25],
            backgroundColor: ['#22c55e', '#e5e7eb'],
            //  cutout: '75%',
            borderWidth: 0,
          },
        ],
      },
      options: {
        plugins: {
          legend: { display: false },
        },
      },
    });
  }
}