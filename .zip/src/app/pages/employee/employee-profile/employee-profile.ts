import { Component } from '@angular/core';
import { IonCard, IonCardContent, IonCardHeader, IonIcon, IonButton, IonCardTitle, IonContent } from "@ionic/angular/standalone";

@Component({
  selector: 'app-employee-profile',
  imports: [IonCard, IonCardContent, IonCardHeader, IonIcon, IonButton, IonCardTitle, IonContent],
  templateUrl: './employee-profile.html',
  styleUrl: './employee-profile.scss'
})
export class EmployeeProfile {
  employee = {
    name: 'Kannan',
    role: 'Senior Mechanic',
    email: 'manikandan@vpsgarage.in',
    phone: '+91 98765 43210',
    joined: '12 Feb 2023',
    totalBookings: 248,
    rating: 4.8,
    image: 'assets/img/kannan.jpeg',
  };

  logout() {
    console.log('Logging out...');
  }
}