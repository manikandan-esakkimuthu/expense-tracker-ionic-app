import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeNotification } from './employee-notification';

describe('EmployeeNotification', () => {
  let component: EmployeeNotification;
  let fixture: ComponentFixture<EmployeeNotification>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmployeeNotification]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeNotification);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
