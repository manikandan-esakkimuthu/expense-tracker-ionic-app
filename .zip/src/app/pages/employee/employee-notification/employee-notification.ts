import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonButton, IonSearchbar, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonIcon, IonCard, IonContent } from "@ionic/angular/standalone";

@Component({
  selector: 'app-employee-notification',
  imports: [IonButton, CommonModule, FormsModule, IonSearchbar, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonIcon, IonCard, IonContent],
  templateUrl: './employee-notification.html',
  styleUrl: './employee-notification.scss'
})
export class EmployeeNotification {
  today = new Date();
  searchTerm = '';

  tasks = [
    {
      customer: 'Rajesh Kumar',
      vehicle: 'Honda City - TN 59 AB 4321',
      service: 'Oil Change & Filter',
      time: '10:30 AM',
      status: 'Pending'
    },
    {
      customer: 'Divya Mani',
      vehicle: 'Suzuki Swift - TN 10 CC 7890',
      service: 'AC Service & General Checkup',
      time: '12:00 PM',
      status: 'In Progress'
    },
    {
      customer: 'Arun S',
      vehicle: 'Hyundai i20 - TN 07 JK 1234',
      service: 'Brake Pad Replacement',
      time: '3:00 PM',
      status: 'Completed'
    }
  ];

  get filteredTasks() {
    if (!this.searchTerm.trim()) return this.tasks;
    return this.tasks.filter(task =>
      task.customer.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      task.service.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  changeStatus(task: any, newStatus: string) {
    task.status = newStatus;
  }
}
