import { Routes } from '@angular/router';
import { EmployeeTabs } from '../employee-tabs/employee-tabs';

export const EMPLOYEE_ROUTES: Routes = [
    {
        path: '',
        component: EmployeeTabs,
        children: [
            // 🧭 Employee Dashboard — Default first page
            {
                path: 'employee-dashboard',
                loadComponent: () =>
                    import('./employee-dashboard/employee-dashboard').then(
                        (m) => m.EmployeeDashboard
                    ),
            },
            {
                path: 'bookings',
                loadComponent: () =>
                    import('./bookings/bookings').then(
                        (m) => m.Bookings
                    ),
            },
            {
                path: 'employee-notification',
                loadComponent: () =>
                    import('./employee-notification/employee-notification').then(
                        (m) => m.EmployeeNotification
                    ),
            },
            {
                path: 'employee-profile',
                loadComponent: () =>
                    import('./employee-profile/employee-profile').then(
                        (m) => m.EmployeeProfile
                    ),
            },
            // 👉 Redirect to dashboard by default
            {
                path: '',
                redirectTo: 'employee-dashboard',
                pathMatch: 'full',
            },
        ],
    },
];
