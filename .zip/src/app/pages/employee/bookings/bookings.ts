import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonCard, IonIcon, IonButton, IonContent } from "@ionic/angular/standalone";

@Component({
  selector: 'app-bookings',
  imports: [IonCard, IonIcon, IonButton, FormsModule, CommonModule, IonContent],
  templateUrl: './bookings.html',
  styleUrl: './bookings.scss'
})
export class Bookings {
  activeTab = 'today';

  bookings = [
    {
      customer: 'Arun Kumar',
      service: 'Engine Oil Change',
      time: '10:30 AM',
      price: '₹800',
      status: 'Confirmed',
    },
    {
      customer: 'Priya Motors',
      service: 'Full Service',
      time: '1:00 PM',
      price: '₹2,000',
      status: 'In Progress',
    },
    {
      customer: 'Siva Raj',
      service: 'Tyre Replacement',
      time: '4:15 PM',
      price: '₹1,200',
      status: 'Completed',
    },
  ];

  changeTab(tab: string) {
    this.activeTab = tab;
  }
}