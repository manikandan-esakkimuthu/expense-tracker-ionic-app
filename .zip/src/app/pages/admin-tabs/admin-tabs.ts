import { Component } from '@angular/core';
import { IonTabButton, IonIcon, IonLabel, IonTabs, IonTabBar } from "@ionic/angular/standalone";
import { addIcons } from 'ionicons';
import { homeOutline, peopleOutline, personCircleOutline, settingsOutline, storefrontOutline } from 'ionicons/icons';
@Component({
  selector: 'app-admin-tabs',
  imports: [IonTabButton, IonIcon, IonLabel, IonTabs, IonTabBar],
  templateUrl: './admin-tabs.html',
  styleUrl: './admin-tabs.scss'
})
export class AdminTabs {
  constructor() {
    addIcons({ homeOutline, storefrontOutline, peopleOutline, personCircleOutline, settingsOutline });
  }

}
