import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import {
  AlertController,
  IonIcon,
  IonLabel,
  IonTabBar,
  IonTabButton,
  IonTabs,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { calendar, calendarOutline, hammer, informationCircle, location, logOutOutline, notifications, people } from 'ionicons/icons';

@Component({
  templateUrl: 'tabs-page.html',
  imports: [
    IonTabs,
    IonTabBar,
    IonTabButton,
    IonIcon,
    IonLabel,
    RouterModule,
  ]
})
export class TabsPage {
  constructor(private router: Router, private alertCtrl: AlertController) {
    addIcons({ calendar, people, location, notifications, informationCircle, hammer, calendarOutline, logOutOutline });
  }
  async logout() {
    const alert = await this.alertCtrl.create({
      header: 'Logout',
      message: 'Are you sure you want to log out?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
        },
        {
          text: 'Yes, Logout',
          handler: () => {
            // 🔹 Clear stored session/token
            localStorage.clear();
            // 🔹 Navigate to login page
            this.router.navigateByUrl('/login', { replaceUrl: true });
          },
        },
      ],
    });
    await alert.present();
  }
}
