import { Component } from '@angular/core';
import { StoreService } from '../store/store.service';
import { IonContent, IonIcon } from "@ionic/angular/standalone";
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin-dashboard',
  imports: [IonContent, IonIcon, FormsModule, CommonModule],
  templateUrl: './admin-dashboard.html',
  styleUrl: './admin-dashboard.scss'
})
export class AdminDashboard {
  stats = { stores: 0, employees: 0, users: 0 };


  constructor(private storeSvc: StoreService) {
    this.stats.stores = this.storeSvc.getAll().length;
    // employees/users can be wired similarly
    this.stats.employees = 12; // placeholder
    this.stats.users = 238; // placeholder
  }

  recentActivities = [
    {
      icon: 'pi pi-cog',
      title: 'Engine Oil Change Completed',
      description: 'Customer Kavin completed oil change at VPS Motors.',
      time: '10 mins ago',
      type: 'booking'
    },
    {
      icon: 'pi pi-user-plus',
      title: 'New Employee Added',
      description: 'Arun joined VPS Tenkasi branch.',
      time: '2 hours ago',
      type: 'employee'
    },
    {
      icon: 'pi pi-home',
      title: 'New Store Registered',
      description: 'VPS Motors - Tirunelveli added successfully.',
      time: '1 day ago',
      type: 'store'
    },
    {
      icon: 'pi pi-exclamation-triangle',
      title: 'Service Reminder Sent',
      description: 'Oil Change Reminder sent to 25 users.',
      time: '3 days ago',
      type: 'alert'
    }
  ];

}
