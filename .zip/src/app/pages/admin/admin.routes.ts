import { Routes } from '@angular/router';
import { AdminTabs } from '../admin-tabs/admin-tabs';

export const ADMIN_ROUTES: Routes = [
    {
        path: '',
        component: AdminTabs,
        children: [
            // 🧭 Admin Dashboard — default first page
            {
                path: 'dashboard',
                loadComponent: () =>
                    import('./admin-dashboard/admin-dashboard').then((m) => m.AdminDashboard),
            },
            // 🏬 Store Management
            {
                path: 'admin-store',
                loadComponent: () =>
                    import('./store/store-list/store-list').then((m) => m.StoreList),
            },
            {
                path: 'employees',
                loadComponent: () =>
                    import('./employee/employee-list/employee-list').then((m) => m.EmployeeList),
            },
            {
                path: 'customer',
                loadComponent: () =>
                    import('./customer/admin-customer-list/admin-customer-list').then((m) => m.AdminCustomerList),
            },
            // 👉 Default redirect to dashboard
            {
                path: '',
                redirectTo: 'dashboard',
                pathMatch: 'full',
            },
        ],
    },
];
