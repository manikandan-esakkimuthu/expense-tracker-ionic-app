import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AlertController, IonFab, IonFabButton, IonIcon, IonButton, IonToggle, IonBadge, IonCard, IonSelect, IonSelectOption, IonContent, ModalController } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { personAddOutline, personRemoveOutline, personCircleOutline, pencilOutline, trashOutline, eyeOutline, banOutline, createOutline, arrowUndoCircleSharp, notificationsOutline, searchOutline } from 'ionicons/icons';
import { EmployeeEditModal } from '../employee-edit-modal/employee-edit-modal';
@Component({
  selector: 'app-employee-list',
  imports: [IonFab, IonFabButton, IonIcon, IonButton, IonToggle, IonBadge, IonCard, IonContent, FormsModule, CommonModule],
  templateUrl: './employee-list.html',
  styleUrl: './employee-list.scss'
})
export class EmployeeList {


  searchTerm = '';
  statusFilter: '' | 'active' | 'suspended' = '';
  employees = [
    {
      id: 1,
      name: 'Kannan',
      role: 'Senior Mechanic',
      phone: '9042519570',
      store: 'VPS KTC Nagar',
      status: 'active',
      avatar: 'assets/img/kannan.jpeg',
    },
    {
      id: 2,
      name: 'Mathan',
      role: 'Mechanic',
      phone: '7092627272',
      store: 'VPS Market',
      //  status: 'suspended',
      status: 'active',
      avatar: 'assets/img/mathan.jpeg',
    },
    {
      id: 3,
      name: 'Mani',
      role: 'Mechanic',
      phone: ' 8870592547',
      store: 'VPS Thachanallur',
      status: 'active',
      avatar: 'assets/img/mani.jpeg',
    },
    {
      id: 4,
      name: 'Vickey',
      role: 'Mechanic',
      phone: '6385505919',
      store: 'VPS Thachanallur',
      status: 'active',
      avatar: 'assets/img/vickey.jpeg',
    },
    {
      id: 5,
      name: 'Prakash',
      role: 'Mechanic',
      phone: '6381559935',
      store: 'VPS Thachanallur',
      status: 'active',
      avatar: 'assets/img/prakash.jpeg',
    },
  ];

  filteredEmployees = [...this.employees];

  constructor(private alertCtrl: AlertController, private modalCtrl: ModalController) {
    addIcons({
      personAddOutline, personRemoveOutline, personCircleOutline, pencilOutline, trashOutline, eyeOutline, banOutline
      , createOutline, arrowUndoCircleSharp, notificationsOutline, searchOutline
    });
  }

  trackById(index: number, item: any) {
    return item.id;
  }

  applySearch() {
    this.filterList();
  }

  applyFilter() {
    this.filterList();
  }

  private filterList() {
    let list = [...this.employees];

    if (this.searchTerm && this.searchTerm.trim() !== '') {
      const q = this.searchTerm.toLowerCase();
      list = list.filter(
        (e) =>
          e.name.toLowerCase().includes(q) ||
          e.role.toLowerCase().includes(q) ||
          e.phone.includes(q) ||
          (e.store && e.store.toLowerCase().includes(q))
      );
    }

    if (this.statusFilter) {
      list = list.filter((e) => e.status === this.statusFilter);
    }

    this.filteredEmployees = list;
  }

  addEmployee() {
    console.log('open add employee modal / page');
    // navigate to add employee or open modal
  }

  async openEmployeeModal(emp?: any, mode: 'add' | 'edit' | 'view' = 'view') {
    const modal = await this.modalCtrl.create({
      component: EmployeeEditModal,
      componentProps: { employee: emp, mode },
      breakpoints: [0, 0.9],
      initialBreakpoint: 0.9,
      backdropDismiss: true,
    });

    modal.onDidDismiss().then((res) => {
      if (res.data && (mode === 'add' || mode === 'edit')) {
        if (mode === 'add') this.employees.push(res.data);
        if (mode === 'edit') {
          const idx = this.employees.findIndex(e => e.id === emp.id);
          if (idx !== -1) this.employees[idx] = res.data;
        }
      }
    });

    await modal.present();
  }


  viewEmployee(emp: any) {
    console.log('view', emp);
    // open details
  }

  async confirmDelete(emp: any) {
    const alert = await this.alertCtrl.create({
      header: 'Delete Employee',
      message: `Delete ${emp.name}? This cannot be undone.`,
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Delete',
          role: 'destructive',
          handler: () => this.deleteEmployee(emp),
        },
      ],
    });
    await alert.present();
  }

  deleteEmployee(emp: any) {
    this.employees = this.employees.filter((e) => e.id !== emp.id);
    this.filterList();
    console.log('deleted', emp);
  }

  toggleSuspend(emp: any) {
    emp.status = emp.status === 'active' ? 'suspended' : 'active';
    this.filterList();
    console.log('toggled', emp.name, emp.status);
  }

  goBack() {
    console.log('go back');
  }

  focusSearch() {
    // optional: focus input via ViewChild if needed
  }
}