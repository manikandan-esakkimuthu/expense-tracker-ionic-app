import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ModalController, IonItem, IonSelect, IonButton, IonSelectOption, IonIcon, IonLabel, IonInput, IonContent } from '@ionic/angular/standalone';

@Component({
  selector: 'app-employee-edit-modal',
  imports: [IonItem, IonSelect, IonButton, CommonModule, FormsModule, IonSelectOption, IonIcon, IonLabel, IonInput, IonContent],
  templateUrl: './employee-edit-modal.html',
  styleUrl: './employee-edit-modal.scss'
})
export class EmployeeEditModal {
  @Input() mode: 'add' | 'edit' | 'view' = 'view';
  @Input() employee: any;
  @Output() save = new EventEmitter<any>();

  empData: any = {};

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
    this.empData = this.employee ? { ...this.employee } : {
      name: '',
      phone: '',
      role: '',
      store: '',
      status: 'active',
      avatar: ''
    };
  }

  dismiss() {
    this.modalCtrl.dismiss();
  }

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => (this.empData.avatar = reader.result as string);
      reader.readAsDataURL(file);
    }
  }

  saveChanges() {
    if (this.mode !== 'view') {
      this.save.emit(this.empData);
    }
    this.modalCtrl.dismiss(this.empData);
  }

  get isViewMode() {
    return this.mode === 'view';
  }

  get modalTitle() {
    return this.mode === 'add'
      ? 'Add Employee'
      : this.mode === 'edit'
        ? 'Edit Employee'
        : 'Employee Details';
  }
}