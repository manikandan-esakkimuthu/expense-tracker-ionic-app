import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StoreModel, StoreService } from '../store.service';
import { IonContent, IonItem, IonButton, IonLabel, IonIcon, IonInput } from "@ionic/angular/standalone";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-store-form',
  imports: [IonContent, IonItem, IonButton, IonLabel, IonIcon, IonInput, FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './store-form.html',
  styleUrl: './store-form.scss'
})
export class StoreForm implements OnInit {
  @Input() store: any;
  @Output() close = new EventEmitter();
  form!: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.form = this.fb.group({
      name: [this.store?.name || '', Validators.required],
      location: [this.store?.location || '', Validators.required],
      phone: [this.store?.phone || '', Validators.required],
      email: [this.store?.email || '', [Validators.required, Validators.email]],
      manager: [this.store?.manager || ''],
      imageUrl: [this.store?.imageUrl || ''],
    });
  }

  save() {
    if (this.form.valid) {
      console.log('✅ Saved Store:', this.form.value);
      this.close.emit(this.form.value);
    }
  }

  cancel() {
    this.close.emit();
  }
}