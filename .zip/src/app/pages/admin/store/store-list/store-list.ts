import { Component } from '@angular/core';
import { StoreModel, StoreService } from '../store.service';
import { IonButton, IonIcon, IonContent, IonFab, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonBadge, IonCardContent, IonFabButton } from "@ionic/angular/standalone";
import { StoreForm } from "../store-form/store-form";
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { addIcons } from 'ionicons';
import { addOutline, arrowUndoCircleSharp, notificationsOutline, pencilOutline, trashOutline } from 'ionicons/icons';
@Component({
  selector: 'app-store-list',
  imports: [FormsModule, CommonModule, IonButton, IonContent, IonIcon],
  templateUrl: './store-list.html',
  styleUrl: './store-list.scss'
})
export class StoreList {
  constructor() {
    addIcons({ addOutline, pencilOutline, trashOutline, notificationsOutline, arrowUndoCircleSharp });
  }
  stores = [
    {
      name: 'VPS KTC Nagar',
      location: '10km near',
      status: 'Active',
      image: 'assets/img/ktc-nagar.jpeg',
    },
    {
      name: 'VPS Market',
      location: '25km near',
      status: 'Active',
      image: 'assets/img/market.jpeg',
    },
    {
      name: 'VPS Vanarapettai',
      location: '55km near',
      status: 'Inactive',
      image: 'assets/img/vanarapettai.jpeg',
    },
  ];
}
