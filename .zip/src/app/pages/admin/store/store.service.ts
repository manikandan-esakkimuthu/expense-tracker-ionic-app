import { Injectable } from '@angular/core';


export interface StoreModel {
    id: string;
    name: string;
    location: string;
    phone?: string;
    openingHours?: string;
    status?: 'Active' | 'Inactive';
    image?: string;
}


@Injectable({ providedIn: 'root' })
export class StoreService {
    private stores: StoreModel[] = [
        {
            id: 's1',
            name: 'VPS KTC Nagar',
            location: 'KTC Nagar',
            phone: '9999999999',
            openingHours: '9:00 AM - 8:00 PM',
            status: 'Active',
            image: 'assets/img/ktc-nagar.jpeg'
        },
        { id: 's2', name: 'VPS Market', location: 'Market Rd', status: 'Active', image: 'assets/img/market.jpeg' },
        { id: 's3', name: 'VPS Vanarapettai', location: 'Vanarapettai', status: 'Inactive' }
    ];


    getAll() { return [...this.stores]; }
    getById(id: string) { return this.stores.find(s => s.id === id); }
    add(store: StoreModel) { this.stores.unshift(store); }
    update(id: string, data: Partial<StoreModel>) {
        const idx = this.stores.findIndex(s => s.id === id);
        if (idx > -1) this.stores[idx] = { ...this.stores[idx], ...data };
    }
    delete(id: string) { this.stores = this.stores.filter(s => s.id !== id); }
}