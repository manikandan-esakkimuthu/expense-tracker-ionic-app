import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonButton, IonIcon, IonSelect, IonSelectOption, IonItem, IonLabel, IonInput, IonContent, ModalController } from "@ionic/angular/standalone";

@Component({
  selector: 'app-customer-modal',
  imports: [IonButton, IonIcon, FormsModule, CommonModule, IonSelect, IonSelectOption, IonItem, IonLabel, IonInput, IonContent],
  templateUrl: './customer-modal.html',
  styleUrl: './customer-modal.scss'
})
export class CustomerModal {
  @Input() mode: 'add' | 'edit' | 'view' = 'view';
  @Input() customer: any;
  @Output() save = new EventEmitter<any>();

  data: any = {};

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
    this.data = this.customer ? { ...this.customer } : {
      name: '',
      phone: '',
      email: '',
      address: '',
      status: 'active',
      avatar: '',
      totalBookings: 0,
      joined: new Date()
    };
  }

  get isView() {
    return this.mode === 'view';
  }

  get title() {
    return this.mode === 'add' ? 'Add Customer' : this.mode === 'edit' ? 'Edit Customer' : 'Customer Details';
  }

  onFileChange(e: any) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => (this.data.avatar = reader.result as string);
    reader.readAsDataURL(f);
  }

  saveAndClose() {
    if (this.mode !== 'view') this.save.emit(this.data);
    this.modalCtrl.dismiss(this.data);
  }

  dismiss() {
    this.modalCtrl.dismiss();
  }
}