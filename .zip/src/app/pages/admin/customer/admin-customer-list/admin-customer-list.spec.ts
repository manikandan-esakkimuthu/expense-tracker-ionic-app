import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCustomerList } from './admin-customer-list';

describe('AdminCustomerList', () => {
  let component: AdminCustomerList;
  let fixture: ComponentFixture<AdminCustomerList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminCustomerList]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminCustomerList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
