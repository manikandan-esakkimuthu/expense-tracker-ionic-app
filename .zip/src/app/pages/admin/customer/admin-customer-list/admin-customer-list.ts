import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonFab, IonFabButton, IonIcon, IonButton, IonSelect, IonSelectOption, IonContent, IonCard, IonBadge, IonChip, IonLabel, AlertController, ModalController } from "@ionic/angular/standalone";
import { CustomerModal } from '../customer-modal/customer-modal';
import { addIcons } from 'ionicons';
import { arrowUndoCircleSharp, notifications, notificationsOutline, searchOutline } from 'ionicons/icons';
@Component({
  selector: 'app-admin-customer-list',
  imports: [IonFab, CommonModule, FormsModule, IonFabButton, IonIcon, IonButton, IonContent, IonCard, IonBadge, IonChip, IonLabel],
  templateUrl: './admin-customer-list.html',
  styleUrl: './admin-customer-list.scss'
})
export class AdminCustomerList {


  searchTerm = '';
  statusFilter: '' | 'active' | 'inactive' = '';
  customers: any[] = [
    { id: 1, name: 'Mani Kumar', phone: '9876543210', email: 'mani@example.com', address: 'Tenkasi', status: 'active', avatar: '', totalBookings: 5, joined: new Date(2024, 6, 1) },
    { id: 2, name: 'Priya', phone: '9876501234', email: 'priya@example.com', address: 'Palayamkottai', status: 'inactive', avatar: '', totalBookings: 1, joined: new Date(2025, 1, 12) },
    { id: 3, name: 'Ramesh', phone: '9876012345', email: 'ramesh@example.com', address: 'Tirunelveli', status: 'active', avatar: '', totalBookings: 3, joined: new Date(2023, 10, 8) },
  ];

  filteredCustomers = [...this.customers];

  constructor(private modalCtrl: ModalController, private alertCtrl: AlertController) {
    addIcons({ arrowUndoCircleSharp, notificationsOutline, searchOutline });
  }

  trackById(i: number, x: any) { return x.id; }

  applySearch() { this.filterList(); }
  applyFilter() { this.filterList(); }

  private filterList() {
    let list = [...this.customers];
    const q = (this.searchTerm || '').trim().toLowerCase();
    if (q) {
      list = list.filter(c =>
        (c.name || '').toLowerCase().includes(q) ||
        (c.phone || '').includes(q) ||
        (c.email || '').toLowerCase().includes(q)
      );
    }
    if (this.statusFilter) {
      list = list.filter(c => c.status === this.statusFilter);
    }
    this.filteredCustomers = list;
  }

  async openCustomerModal(customer?: any, mode: 'add' | 'edit' | 'view' = 'view') {
    const modal = await this.modalCtrl.create({
      component: CustomerModal,
      componentProps: { customer, mode },
      breakpoints: [0, 0.9],
      initialBreakpoint: 0.9,
      backdropDismiss: true
    });

    modal.onDidDismiss().then(res => {
      if (!res || !res.data) return;
      const data = res.data;
      if (mode === 'add') {
        data.id = this.customers.length ? Math.max(...this.customers.map(c => c.id)) + 1 : 1;
        this.customers.unshift(data);
      } else if (mode === 'edit') {
        const idx = this.customers.findIndex(c => c.id === customer.id);
        if (idx !== -1) this.customers[idx] = data;
      }
      this.filterList();
    });

    await modal.present();
  }

  async confirmDelete(cust: any) {
    const a = await this.alertCtrl.create({
      header: 'Delete Customer',
      message: `Delete ${cust.name}? This cannot be undone.`,
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        { text: 'Delete', role: 'destructive', handler: () => this.deleteCustomer(cust) }
      ]
    });
    await a.present();
  }

  deleteCustomer(cust: any) {
    this.customers = this.customers.filter(x => x.id !== cust.id);
    this.filterList();
  }

  goBack() { console.log('goBack'); }
  focusSearch() { /* optional focus logic */ }
}
