import { Component } from '@angular/core';
import { IonIcon, IonContent } from "@ionic/angular/standalone";
import { addIcons } from 'ionicons';
import { alertCircleOutline, arrowBackOutline, arrowUndoCircleSharp, checkmarkDoneCircleOutline, giftOutline, notificationsOutline, settingsOutline } from 'ionicons/icons';
@Component({
  selector: 'app-user-notification',
  imports: [IonIcon, IonContent],
  templateUrl: './user-notification.html',
  styleUrl: './user-notification.scss'
})
export class UserNotification {

  constructor() {
    addIcons({ giftOutline, arrowUndoCircleSharp, notificationsOutline, settingsOutline, checkmarkDoneCircleOutline, alertCircleOutline, arrowBackOutline });
  }
}
