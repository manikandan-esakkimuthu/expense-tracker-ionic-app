import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { IonButton, IonIcon, IonContent, IonFab, IonFabButton, IonFabList, LoadingController } from "@ionic/angular/standalone";
import { addIcons } from 'ionicons';
import { arrowUndoCircleSharp, batteryChargingOutline, bicycleOutline, buildOutline, bulbOutline, carSport, carSportOutline, clipboardOutline, constructOutline, flashOutline, logoFacebook, logoInstagram, logoTwitch, logoTwitter, logoWhatsapp, notificationsOutline, searchOutline, settingsOutline, shareSocial, sparklesOutline, speedometerOutline } from 'ionicons/icons';

@Component({
  selector: 'app-service-details',
  imports: [IonButton, IonIcon, IonContent, CommonModule, IonFab, IonFabButton, IonFabList],
  templateUrl: './service-details.html',
  styleUrl: './service-details.scss'
})
export class ServiceDetails {
  loadingCtrl = inject(LoadingController);
  constructor() {
    addIcons({
      arrowUndoCircleSharp,
      notificationsOutline,
      searchOutline,
      speedometerOutline,
      sparklesOutline,
      constructOutline, bicycleOutline, settingsOutline, flashOutline, carSportOutline,
      buildOutline, batteryChargingOutline, bulbOutline,
      clipboardOutline, shareSocial, logoWhatsapp, logoInstagram, logoTwitter, logoFacebook
    });

  }
  categories = [
    { name: 'Bike Care', icon: 'bicycle-outline' },
    { name: 'General Service', icon: 'settings-outline' },
    { name: 'Repairs', icon: 'construct-outline' },
    { name: 'Electrical', icon: 'flash-outline' },
    { name: 'Tyres', icon: 'car-sport-outline' },
  ];

  selectedCategory = 'Bike Care';

  allServices: any = {
    'Bike Care': [
      {
        name: 'Engine Oil & Filter',
        description: 'Complete oil change and filter cleaning',
        icon: 'construct-outline',
        price: 499,
        oldPrice: 699,
      },
      {
        name: 'Bike Wash',
        description: 'Full body foam wash & polish',
        icon: 'sparkles-outline',
        price: 249,
        oldPrice: 349,
      },
      {
        name: 'Chain Lubrication',
        description: 'Lubricate and tighten bike chain',
        icon: 'speedometer-outline',
        price: 199,
        oldPrice: 249,
      },
    ],
    'General Service': [
      {
        name: 'Full Body Checkup',
        description: 'Multi-point inspection with test ride',
        icon: 'clipboard-outline',
        price: 899,
        oldPrice: 1099,
      },
      {
        name: 'Brake & Clutch Service',
        description: 'Check & replace worn-out parts',
        icon: 'build-outline',
        price: 599,
        oldPrice: 749,
      },
    ],
    Repairs: [
      {
        name: 'Electrical Repair',
        description: 'Battery, wiring & fuse repair',
        icon: 'flash-outline',
        price: 799,
        oldPrice: 999,
      },
      {
        name: 'Tyre Replacement',
        description: 'Wheel balance & tyre replacement',
        icon: 'car-sport-outline',
        price: 1199,
        oldPrice: 1499,
      },
    ],
    Electrical: [
      {
        name: 'Battery Checkup',
        description: 'Voltage test & terminal cleaning',
        icon: 'battery-charging-outline',
        price: 299,
        oldPrice: 399,
      },
      {
        name: 'Headlight Repair',
        description: 'Bulb & wiring replacement',
        icon: 'bulb-outline',
        price: 499,
        oldPrice: 699,
      },
    ],
    Tyres: [
      {
        name: 'Tyre Replacement',
        description: 'New tyre fitting and balancing',
        icon: 'car-sport-outline',
        price: 999,
        oldPrice: 1199,
      },
    ],
  };

  get services() {
    return this.allServices[this.selectedCategory];
  }

  selectCategory(cat: string) {
    this.selectedCategory = cat;
  }

  bookService(service: any) {
    console.log('Booking:', service.name);
  }
  async openSocial(network: string, fab: IonFab) {
    const loading = await this.loadingCtrl.create({
      message: `Posting to ${network}`,
      duration: Math.random() * 1000 + 500,
    });
    await loading.present();
    await loading.onWillDismiss();
    fab.close();
  }

}