import { NgFor, NgIf } from '@angular/common';
import { Component, signal } from '@angular/core';
import { IonCard, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonContent, IonButton } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { location, locationOutline, notifications, notificationsOutline, search, searchOutline, storefront, storefrontOutline } from 'ionicons/icons';


@Component({
  selector: 'app-store-details',
  imports: [IonCard, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonContent, IonButton],
  templateUrl: './store-details.html',
  styleUrl: './store-details.scss'
})
export class StoreDetails {
  constructor() {
    addIcons({ storefrontOutline, locationOutline, notificationsOutline, searchOutline });
  }

}
