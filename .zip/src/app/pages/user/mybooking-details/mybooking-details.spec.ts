import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MybookingDetails } from './mybooking-details';

describe('MybookingDetails', () => {
  let component: MybookingDetails;
  let fixture: ComponentFixture<MybookingDetails>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MybookingDetails]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MybookingDetails);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
