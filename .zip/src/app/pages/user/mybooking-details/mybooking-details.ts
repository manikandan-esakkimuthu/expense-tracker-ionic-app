import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonButton, IonIcon, IonContent } from "@ionic/angular/standalone";
import { addIcons } from 'ionicons';
import { arrowUndoCircleSharp, notificationsOutline, searchOutline, speedometerOutline, sparklesOutline, constructOutline, bicycleOutline, settingsOutline, flashOutline, carSportOutline, buildOutline, batteryChargingOutline, bulbOutline, clipboardOutline } from 'ionicons/icons';

@Component({
  selector: 'app-mybooking-details',
  imports: [IonButton, IonIcon, IonContent, FormsModule, CommonModule],
  templateUrl: './mybooking-details.html',
  styleUrl: './mybooking-details.scss'
})
export class MybookingDetails {

  constructor() {
    addIcons({
      arrowUndoCircleSharp,
      notificationsOutline,
      searchOutline,
      speedometerOutline,
      sparklesOutline,
      constructOutline, bicycleOutline, settingsOutline, flashOutline, carSportOutline,
      buildOutline, batteryChargingOutline, bulbOutline,
      clipboardOutline,
    });

  }
  activeTab: string = 'active';
  lastTab: string = 'active';

  activeBookings = [
    { name: 'Engine Oil & Filter', icon: 'construct-outline', date: '31 Oct', time: '11:00 AM', status: 'Confirmed', originalPrice: 699, discountPrice: 499 },
    { name: 'Bike Wash', icon: 'sparkles-outline', date: '1 Nov', time: '9:30 AM', status: 'InProgress', originalPrice: 299, discountPrice: 249 }
  ];

  pastBookings = [
    { name: 'Chain Lubrication', icon: 'speedometer-outline', date: '28 Oct', time: '2:00 PM', status: 'Completed', originalPrice: 249, discountPrice: 199 }
  ];

  switchTab(tab: string) {
    this.lastTab = this.activeTab;
    this.activeTab = tab;
  }
}
