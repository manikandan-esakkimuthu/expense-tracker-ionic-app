import { Routes } from '@angular/router';
import { TabsPage } from '../tabs-page/tabs-page';

export const USER_ROUTES: Routes = [
    {
        path: '',
        component: TabsPage,
        children: [
            // 🏬 Store Page — Default First
            {
                path: 'store',
                loadComponent: () =>
                    import('./store-details/store-details').then((m) => m.StoreDetails),
            },
            // 🧾 Service Page
            {
                path: 'service',
                loadComponent: () =>
                    import('./service-details/service-details').then((m) => m.ServiceDetails),
            },
            // 📅 My Booking Page
            {
                path: 'mybooking',
                loadComponent: () =>
                    import('./mybooking-details/mybooking-details').then((m) => m.MybookingDetails),
            },
            // 🔔 Notification Page
            {
                path: 'user-notification',
                loadComponent: () =>
                    import('./user-notification/user-notification').then((m) => m.UserNotification),
            },

            // 👉 Default Redirect (Load Store First)
            {
                path: '',
                redirectTo: 'store',
                pathMatch: 'full',
            },
        ],
    },
];
