import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },

  {
    path: 'login',
    loadComponent: () =>
      import('./pages/my-login/my-login').then((m) => m.MyLogin),
  },

  // 🧩 Admin routes
  {
    path: 'admin',
    loadChildren: () =>
      import('./pages/admin/admin.routes').then((m) => m.ADMIN_ROUTES),
  },

  // 🧑‍💼 Employee routes
  {
    path: 'employee',
    loadChildren: () =>
      import('./pages/employee/employee.routes').then((m) => m.EMPLOYEE_ROUTES),
  },

  // 👤 User routes
  {
    path: 'user',
    loadChildren: () =>
      import('./pages/user/user.routes').then((m) => m.USER_ROUTES),
  },
  {
    path: 'expense',
    loadChildren: () =>
      import('./pages/expense/expense.routes').then((m) => m.EXPENSE_ROUTES),
  },


  // 🔁 Wildcard redirect
  {
    path: '**',
    redirectTo: 'login',
  },
];
