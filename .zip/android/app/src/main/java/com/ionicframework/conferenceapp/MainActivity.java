package com.ionicframework.conferenceapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
