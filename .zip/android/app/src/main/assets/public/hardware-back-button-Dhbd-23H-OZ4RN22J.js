import {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
} from "./chunk-5YIQV2FO.js";
import "./chunk-IVBL4Y7V.js";
import "./chunk-NNTRQ7Y2.js";
import "./chunk-EAE2VPRF.js";
export {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
};
//# sourceMappingURL=hardware-back-button-Dhbd-23H-OZ4RN22J.js.map
