import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-CEAAMTO4.js";
import "./chunk-EAE2VPRF.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
//# sourceMappingURL=index3-YLMP27OY.js.map
