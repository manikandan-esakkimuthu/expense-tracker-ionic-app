import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵtext
} from "./chunk-NPNYO6CD.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/expense/users/reports/reports.ts
var _Reports = class _Reports {
};
_Reports.\u0275fac = function Reports_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _Reports)();
};
_Reports.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Reports, selectors: [["app-reports"]], decls: 2, vars: 0, template: function Reports_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p");
    \u0275\u0275text(1, "reports works!");
    \u0275\u0275domElementEnd();
  }
}, encapsulation: 2 });
var Reports = _Reports;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Reports, [{
    type: Component,
    args: [{ selector: "app-reports", imports: [], template: "<p>reports works!</p>\r\n" }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Reports, { className: "Reports", filePath: "src/app/pages/expense/users/reports/reports.ts", lineNumber: 9 });
})();
export {
  Reports
};
//# sourceMappingURL=reports-6ZTQGMPO.js.map
