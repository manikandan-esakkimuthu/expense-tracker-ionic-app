import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonContent,
  IonIcon,
  IonSearchbar
} from "./chunk-OIW4YKS2.js";
import {
  CommonModule,
  DatePipe,
  FormsModule,
  NgClass,
  NgControlStatus,
  NgForOf,
  NgIf,
  NgModel
} from "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/employee/employee-notification/employee-notification.ts
function EmployeeNotification_ion_card_11_ion_button_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 16);
    \u0275\u0275listener("click", function EmployeeNotification_ion_card_11_ion_button_17_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const task_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.changeStatus(task_r2, "In Progress"));
    });
    \u0275\u0275text(1, " Start ");
    \u0275\u0275elementEnd();
  }
}
function EmployeeNotification_ion_card_11_ion_button_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 17);
    \u0275\u0275listener("click", function EmployeeNotification_ion_card_11_ion_button_18_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const task_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.changeStatus(task_r2, "Completed"));
    });
    \u0275\u0275text(1, " Complete ");
    \u0275\u0275elementEnd();
  }
}
function EmployeeNotification_ion_card_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 7)(1, "ion-card-header")(2, "ion-card-title");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-card-subtitle");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "ion-card-content")(7, "p");
    \u0275\u0275element(8, "ion-icon", 8);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "p");
    \u0275\u0275element(11, "ion-icon", 9);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 10)(14, "span", 11);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "div", 12);
    \u0275\u0275template(17, EmployeeNotification_ion_card_11_ion_button_17_Template, 2, 0, "ion-button", 13)(18, EmployeeNotification_ion_card_11_ion_button_18_Template, 2, 0, "ion-button", 14);
    \u0275\u0275elementStart(19, "ion-button", 15);
    \u0275\u0275text(20, " View ");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const task_r2 = ctx.$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(task_r2.customer);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(task_r2.vehicle);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", task_r2.service);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", task_r2.time);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngClass", task_r2.status.toLowerCase());
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", task_r2.status, " ");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", task_r2.status === "Pending");
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", task_r2.status === "In Progress");
  }
}
var _EmployeeNotification = class _EmployeeNotification {
  constructor() {
    this.today = /* @__PURE__ */ new Date();
    this.searchTerm = "";
    this.tasks = [
      {
        customer: "Rajesh Kumar",
        vehicle: "Honda City - TN 59 AB 4321",
        service: "Oil Change & Filter",
        time: "10:30 AM",
        status: "Pending"
      },
      {
        customer: "Divya Mani",
        vehicle: "Suzuki Swift - TN 10 CC 7890",
        service: "AC Service & General Checkup",
        time: "12:00 PM",
        status: "In Progress"
      },
      {
        customer: "Arun S",
        vehicle: "Hyundai i20 - TN 07 JK 1234",
        service: "Brake Pad Replacement",
        time: "3:00 PM",
        status: "Completed"
      }
    ];
  }
  get filteredTasks() {
    if (!this.searchTerm.trim())
      return this.tasks;
    return this.tasks.filter((task) => task.customer.toLowerCase().includes(this.searchTerm.toLowerCase()) || task.service.toLowerCase().includes(this.searchTerm.toLowerCase()));
  }
  changeStatus(task, newStatus) {
    task.status = newStatus;
  }
};
_EmployeeNotification.\u0275fac = function EmployeeNotification_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EmployeeNotification)();
};
_EmployeeNotification.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _EmployeeNotification, selectors: [["app-employee-notification"]], decls: 12, vars: 6, consts: [[1, "tasks-page"], [1, "header"], [1, "greeting", "fade-in"], [1, "search-container", "slide-up"], ["placeholder", "Search by name or service", 3, "ngModelChange", "ngModel"], [1, "task-list"], ["class", "task-card fade-in", 4, "ngFor", "ngForOf"], [1, "task-card", "fade-in"], ["name", "build-outline"], ["name", "time-outline"], [1, "status-row"], [1, "status-chip", 3, "ngClass"], [1, "action-row"], ["size", "small", "fill", "outline", "color", "primary", 3, "click", 4, "ngIf"], ["size", "small", "fill", "outline", "color", "success", 3, "click", 4, "ngIf"], ["size", "small", "fill", "clear", "color", "medium"], ["size", "small", "fill", "outline", "color", "primary", 3, "click"], ["size", "small", "fill", "outline", "color", "success", 3, "click"]], template: function EmployeeNotification_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1)(2, "div", 2)(3, "h2");
    \u0275\u0275text(4, "Good Morning, Manikandan \u{1F44B}");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "date");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(8, "div", 3)(9, "ion-searchbar", 4);
    \u0275\u0275twoWayListener("ngModelChange", function EmployeeNotification_Template_ion_searchbar_ngModelChange_9_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.searchTerm, $event) || (ctx.searchTerm = $event);
      return $event;
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 5);
    \u0275\u0275template(11, EmployeeNotification_ion_card_11_Template, 21, 8, "ion-card", 6);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(7, 3, ctx.today, "fullDate"));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx.searchTerm);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", ctx.filteredTasks);
  }
}, dependencies: [IonButton, CommonModule, NgClass, NgForOf, NgIf, FormsModule, NgControlStatus, NgModel, IonSearchbar, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonIcon, IonCard, IonContent, DatePipe], styles: ["\n\n.tasks-page[_ngcontent-%COMP%] {\n  background: #f9fafb;\n}\n.tasks-page[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #3b82f6,\n      #60a5fa);\n  color: #fff;\n  padding: 40px 16px 70px;\n  border-bottom-left-radius: 40px;\n  border-bottom-right-radius: 40px;\n  text-align: center;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n}\n.tasks-page[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]   .greeting[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 700;\n}\n.tasks-page[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]   .greeting[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 14px;\n  opacity: 0.9;\n}\n.tasks-page[_ngcontent-%COMP%]   .search-container[_ngcontent-%COMP%] {\n  margin: -30px 16px 10px;\n}\n.tasks-page[_ngcontent-%COMP%]   .search-container[_ngcontent-%COMP%]   ion-searchbar[_ngcontent-%COMP%] {\n  --border-radius: 16px;\n  --background: #fff;\n  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%] {\n  padding: 10px 16px 50px;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%] {\n  border-radius: 16px;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);\n  margin-bottom: 16px;\n  animation-delay: 0.1s;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-weight: 700;\n  color: #111827;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-subtitle[_ngcontent-%COMP%] {\n  color: #6b7280;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #374151;\n  margin: 6px 0;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #2563eb;\n  font-size: 18px;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%]   .status-row[_ngcontent-%COMP%] {\n  margin: 10px 0;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%]   .status-row[_ngcontent-%COMP%]   .status-chip[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  padding: 4px 10px;\n  border-radius: 12px;\n  text-transform: uppercase;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%]   .status-row[_ngcontent-%COMP%]   .status-chip.pending[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #92400e;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%]   .status-row[_ngcontent-%COMP%]   .status-chip.in\\ progress[_ngcontent-%COMP%] {\n  background: #dbeafe;\n  color: #1d4ed8;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%]   .status-row[_ngcontent-%COMP%]   .status-chip.completed[_ngcontent-%COMP%] {\n  background: #dcfce7;\n  color: #166534;\n}\n.tasks-page[_ngcontent-%COMP%]   .task-list[_ngcontent-%COMP%]   .task-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%]   .action-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 10px;\n}\n.tasks-page[_ngcontent-%COMP%]   .fade-in[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_fadeIn 0.6s ease both;\n}\n.tasks-page[_ngcontent-%COMP%]   .slide-up[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_slideUp 0.7s ease both;\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes _ngcontent-%COMP%_slideUp {\n  from {\n    opacity: 0;\n    transform: translateY(30px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=employee-notification.css.map */"] });
var EmployeeNotification = _EmployeeNotification;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EmployeeNotification, [{
    type: Component,
    args: [{ selector: "app-employee-notification", imports: [IonButton, CommonModule, FormsModule, IonSearchbar, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonIcon, IonCard, IonContent], template: `<ion-content class="tasks-page">\r
\r
    <!-- \u{1F305} Header -->\r
    <div class="header">\r
        <div class="greeting fade-in">\r
            <h2>Good Morning, Manikandan \u{1F44B}</h2>\r
            <p>{{ today | date:'fullDate' }}</p>\r
        </div>\r
    </div>\r
\r
    <!-- \u{1F50D} Search Bar -->\r
    <div class="search-container slide-up">\r
        <ion-searchbar [(ngModel)]="searchTerm" placeholder="Search by name or service"></ion-searchbar>\r
    </div>\r
\r
    <!-- \u{1F4CB} Task List -->\r
    <div class="task-list">\r
        <ion-card *ngFor="let task of filteredTasks" class="task-card fade-in">\r
            <ion-card-header>\r
                <ion-card-title>{{ task.customer }}</ion-card-title>\r
                <ion-card-subtitle>{{ task.vehicle }}</ion-card-subtitle>\r
            </ion-card-header>\r
\r
            <ion-card-content>\r
                <p><ion-icon name="build-outline"></ion-icon> {{ task.service }}</p>\r
                <p><ion-icon name="time-outline"></ion-icon> {{ task.time }}</p>\r
\r
                <div class="status-row">\r
                    <span class="status-chip" [ngClass]="task.status.toLowerCase()">\r
                        {{ task.status }}\r
                    </span>\r
                </div>\r
\r
                <div class="action-row">\r
                    <ion-button size="small" fill="outline" color="primary" *ngIf="task.status === 'Pending'"\r
                        (click)="changeStatus(task, 'In Progress')">\r
                        Start\r
                    </ion-button>\r
\r
                    <ion-button size="small" fill="outline" color="success" *ngIf="task.status === 'In Progress'"\r
                        (click)="changeStatus(task, 'Completed')">\r
                        Complete\r
                    </ion-button>\r
\r
                    <ion-button size="small" fill="clear" color="medium">\r
                        View\r
                    </ion-button>\r
                </div>\r
            </ion-card-content>\r
        </ion-card>\r
    </div>\r
\r
</ion-content>`, styles: ["/* src/app/pages/employee/employee-notification/employee-notification.scss */\n.tasks-page {\n  background: #f9fafb;\n}\n.tasks-page .header {\n  background:\n    linear-gradient(\n      135deg,\n      #3b82f6,\n      #60a5fa);\n  color: #fff;\n  padding: 40px 16px 70px;\n  border-bottom-left-radius: 40px;\n  border-bottom-right-radius: 40px;\n  text-align: center;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n}\n.tasks-page .header .greeting h2 {\n  font-size: 22px;\n  font-weight: 700;\n}\n.tasks-page .header .greeting p {\n  font-size: 14px;\n  opacity: 0.9;\n}\n.tasks-page .search-container {\n  margin: -30px 16px 10px;\n}\n.tasks-page .search-container ion-searchbar {\n  --border-radius: 16px;\n  --background: #fff;\n  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);\n}\n.tasks-page .task-list {\n  padding: 10px 16px 50px;\n}\n.tasks-page .task-list .task-card {\n  border-radius: 16px;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);\n  margin-bottom: 16px;\n  animation-delay: 0.1s;\n}\n.tasks-page .task-list .task-card ion-card-title {\n  font-weight: 700;\n  color: #111827;\n}\n.tasks-page .task-list .task-card ion-card-subtitle {\n  color: #6b7280;\n}\n.tasks-page .task-list .task-card ion-card-content p {\n  font-size: 14px;\n  color: #374151;\n  margin: 6px 0;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.tasks-page .task-list .task-card ion-card-content p ion-icon {\n  color: #2563eb;\n  font-size: 18px;\n}\n.tasks-page .task-list .task-card ion-card-content .status-row {\n  margin: 10px 0;\n}\n.tasks-page .task-list .task-card ion-card-content .status-row .status-chip {\n  font-size: 12px;\n  font-weight: 600;\n  padding: 4px 10px;\n  border-radius: 12px;\n  text-transform: uppercase;\n}\n.tasks-page .task-list .task-card ion-card-content .status-row .status-chip.pending {\n  background: #fef3c7;\n  color: #92400e;\n}\n.tasks-page .task-list .task-card ion-card-content .status-row .status-chip.in\\ progress {\n  background: #dbeafe;\n  color: #1d4ed8;\n}\n.tasks-page .task-list .task-card ion-card-content .status-row .status-chip.completed {\n  background: #dcfce7;\n  color: #166534;\n}\n.tasks-page .task-list .task-card ion-card-content .action-row {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 10px;\n}\n.tasks-page .fade-in {\n  animation: fadeIn 0.6s ease both;\n}\n.tasks-page .slide-up {\n  animation: slideUp 0.7s ease both;\n}\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes slideUp {\n  from {\n    opacity: 0;\n    transform: translateY(30px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=employee-notification.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(EmployeeNotification, { className: "EmployeeNotification", filePath: "src/app/pages/employee/employee-notification/employee-notification.ts", lineNumber: 12 });
})();
export {
  EmployeeNotification
};
//# sourceMappingURL=employee-notification-XTA6PZSV.js.map
