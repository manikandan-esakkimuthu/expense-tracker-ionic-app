import {
  locationOutline,
  notificationsOutline,
  searchOutline,
  storefrontOutline
} from "./chunk-TD74DZFV.js";
import {
  IonButton,
  IonCard,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonContent,
  IonIcon
} from "./chunk-OIW4YKS2.js";
import "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵtext
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/user/store-details/store-details.ts
var _StoreDetails = class _StoreDetails {
  constructor() {
    addIcons({ storefrontOutline, locationOutline, notificationsOutline, searchOutline });
  }
};
_StoreDetails.\u0275fac = function StoreDetails_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _StoreDetails)();
};
_StoreDetails.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _StoreDetails, selectors: [["app-store-details"]], decls: 55, vars: 0, consts: [[1, "store-page"], [1, "top-bar"], [1, "search-box"], ["name", "search-outline", 1, "search-icon"], ["type", "text", "placeholder", "Search stores..."], ["name", "notifications-outline", 1, "notif-icon"], [1, "cards-column"], [1, "place-card"], [1, "image-container"], ["src", "assets/img/ktc-nagar.jpeg", "alt", "Store"], [1, "card-header-row"], [1, "card-info"], [1, "title-row"], ["name", "storefront-outline", 1, "title-icon"], [1, "subtitle-row"], ["name", "location", 1, "subtitle-icon"], ["fill", "outline", "size", "small", 1, "view-btn"], ["src", "assets/img/market.jpeg", "alt", "Store"], ["name", "storefront", 1, "title-icon"], ["src", "assets/img/thachanallur.jpeg", "alt", "Store"]], template: function StoreDetails_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1)(2, "div", 2);
    \u0275\u0275element(3, "ion-icon", 3)(4, "input", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275element(5, "ion-icon", 5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 6)(7, "ion-card", 7)(8, "div", 8);
    \u0275\u0275element(9, "img", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "ion-card-header")(11, "div", 10)(12, "div", 11)(13, "div", 12);
    \u0275\u0275element(14, "ion-icon", 13);
    \u0275\u0275elementStart(15, "ion-card-title");
    \u0275\u0275text(16, "VPS KTC Nagar");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 14);
    \u0275\u0275element(18, "ion-icon", 15);
    \u0275\u0275elementStart(19, "ion-card-subtitle");
    \u0275\u0275text(20, "10km near");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "ion-button", 16);
    \u0275\u0275text(22, " View ");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(23, "ion-card", 7)(24, "div", 8);
    \u0275\u0275element(25, "img", 17);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "ion-card-header")(27, "div", 10)(28, "div", 11)(29, "div", 12);
    \u0275\u0275element(30, "ion-icon", 18);
    \u0275\u0275elementStart(31, "ion-card-title");
    \u0275\u0275text(32, "VPS- Market");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(33, "div", 14);
    \u0275\u0275element(34, "ion-icon", 15);
    \u0275\u0275elementStart(35, "ion-card-subtitle");
    \u0275\u0275text(36, "15km near");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(37, "ion-button", 16);
    \u0275\u0275text(38, " View ");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(39, "ion-card", 7)(40, "div", 8);
    \u0275\u0275element(41, "img", 19);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "ion-card-header")(43, "div", 10)(44, "div", 11)(45, "div", 12);
    \u0275\u0275element(46, "ion-icon", 18);
    \u0275\u0275elementStart(47, "ion-card-title");
    \u0275\u0275text(48, "VPS KTC Nagar");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(49, "div", 14);
    \u0275\u0275element(50, "ion-icon", 15);
    \u0275\u0275elementStart(51, "ion-card-subtitle");
    \u0275\u0275text(52, "10km near");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(53, "ion-button", 16);
    \u0275\u0275text(54, " View ");
    \u0275\u0275elementEnd()()()()()();
  }
}, dependencies: [IonCard, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonContent, IonButton], styles: ['@charset "UTF-8";\n\n\n\n.store-page[_ngcontent-%COMP%] {\n  --background:\n    linear-gradient(\n      180deg,\n      #f7f9ff 0%,\n      #ffffff 100%);\n  display: flex;\n  flex-direction: column;\n  padding: 0;\n  overflow: hidden;\n}\n.top-bar[_ngcontent-%COMP%] {\n  position: sticky;\n  top: 0;\n  z-index: 10;\n  background: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 10px 14px;\n  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);\n  border-bottom-left-radius: 14px;\n  border-bottom-right-radius: 14px;\n}\n.search-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #f1f3fa;\n  border-radius: 25px;\n  padding: 6px 14px;\n  flex: 1;\n  margin-right: 12px;\n  transition: all 0.3s ease-in-out;\n}\n.search-box[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  flex: 1;\n  border: none;\n  outline: none;\n  background: transparent;\n  font-size: 15px;\n  padding-left: 6px;\n  color: #333;\n}\n.search-box[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #555;\n}\n.search-box[_ngcontent-%COMP%]:focus-within {\n  background: #e7ebff;\n  box-shadow: 0 0 0 2px rgba(56, 128, 255, 0.2);\n}\n.notif-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #444;\n  cursor: pointer;\n  transition: transform 0.2s ease, color 0.2s ease;\n}\n.notif-icon[_ngcontent-%COMP%]:hover {\n  transform: scale(1.1);\n  color: #3880ff;\n}\n.cards-column[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  padding: 14px;\n  overflow-y: auto;\n  height: calc(100vh - 70px);\n  padding-bottom: 24px;\n}\n.place-card[_ngcontent-%COMP%] {\n  border-radius: 14px;\n  overflow: hidden;\n  background: #fff;\n  box-shadow: 0 6px 14px rgba(0, 0, 0, 0.08);\n  transition: transform 0.25s ease, box-shadow 0.25s ease;\n  flex: 0 0 auto;\n}\n.place-card[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 110px;\n  object-fit: cover;\n}\n.place-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  padding: 10px 12px;\n}\n.place-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 600;\n  color: #222;\n}\n.place-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%]   ion-card-subtitle[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #666;\n}\n.place-card[_ngcontent-%COMP%]:hover {\n  transform: scale(1.02);\n  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);\n}\n.cards-column[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 6px;\n}\n.cards-column[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  background: rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n}\n.place-card[_ngcontent-%COMP%] {\n  border-radius: 16px;\n  overflow: hidden;\n  background: #fff;\n  box-shadow: 0 6px 14px rgba(0, 0, 0, 0.08);\n  transition: transform 0.25s ease, box-shadow 0.25s ease;\n  margin-bottom: 14px;\n}\n.place-card[_ngcontent-%COMP%]:hover {\n  transform: scale(1.02);\n  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);\n}\n.image-container[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 140px;\n  overflow: hidden;\n  position: relative;\n  border-bottom: 1px solid #eee;\n}\n.image-container[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  display: block;\n  transition: transform 0.3s ease;\n}\n.image-container[_ngcontent-%COMP%]:hover   img[_ngcontent-%COMP%] {\n  transform: scale(1.05);\n}\n.card-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding-right: 6px;\n}\n.card-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.card-info[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 600;\n  color: #222;\n  margin-bottom: 4px;\n}\n.card-info[_ngcontent-%COMP%]   ion-card-subtitle[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #666;\n}\n.view-btn[_ngcontent-%COMP%] {\n  --border-radius: 20px;\n  --padding-start: 12px;\n  --padding-end: 12px;\n  font-size: 13px;\n  font-weight: 500;\n  text-transform: none;\n  --border-color: #3880ff;\n  --color: #3880ff;\n  --ripple-color: rgba(56, 128, 255, 0.3);\n  transition: all 0.2s ease;\n}\n.view-btn[_ngcontent-%COMP%]:hover {\n  background: #3880ff;\n  color: #fff;\n}\n@media (max-width: 400px) {\n  .image-container[_ngcontent-%COMP%] {\n    height: 120px;\n  }\n}\n.place-card[_ngcontent-%COMP%] {\n  border-radius: 16px;\n  overflow: hidden;\n  background: #fff;\n  box-shadow: 0 6px 14px rgba(0, 0, 0, 0.08);\n  transition: transform 0.25s ease, box-shadow 0.25s ease;\n  margin-bottom: 14px;\n}\n.place-card[_ngcontent-%COMP%]:hover {\n  transform: scale(1.02);\n  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);\n}\n.image-container[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 140px;\n  overflow: hidden;\n  position: relative;\n  border-bottom: 1px solid #eee;\n}\n.image-container[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  display: block;\n  transition: transform 0.3s ease;\n}\n.image-container[_ngcontent-%COMP%]:hover   img[_ngcontent-%COMP%] {\n  transform: scale(1.05);\n}\n.card-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding-right: 6px;\n}\n.card-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.title-row[_ngcontent-%COMP%]   .title-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #3880ff;\n}\n.title-row[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 600;\n  color: #222;\n}\n.subtitle-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.subtitle-row[_ngcontent-%COMP%]   .subtitle-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n  color: #666;\n}\n.subtitle-row[_ngcontent-%COMP%]   ion-card-subtitle[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #666;\n}\n.view-btn[_ngcontent-%COMP%] {\n  --border-radius: 20px;\n  --padding-start: 12px;\n  --padding-end: 12px;\n  font-size: 13px;\n  font-weight: 500;\n  text-transform: none;\n  --border-color: #3880ff;\n  --color: #3880ff;\n  transition: all 0.2s ease;\n}\n.view-btn[_ngcontent-%COMP%]:hover {\n  background: #3880ff;\n  color: #fff;\n}\n@media (max-width: 400px) {\n  .image-container[_ngcontent-%COMP%] {\n    height: 120px;\n  }\n  ion-card-title[_ngcontent-%COMP%] {\n    font-size: 15px;\n  }\n}\n/*# sourceMappingURL=store-details.css.map */'] });
var StoreDetails = _StoreDetails;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreDetails, [{
    type: Component,
    args: [{ selector: "app-store-details", imports: [IonCard, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonContent, IonButton], template: '<ion-content class="store-page">\r\n\r\n    <!-- \u{1F50D} Sticky Top Bar -->\r\n    <div class="top-bar">\r\n        <div class="search-box">\r\n            <ion-icon name="search-outline" class="search-icon"></ion-icon>\r\n            <input type="text" placeholder="Search stores..." />\r\n        </div>\r\n        <ion-icon name="notifications-outline" class="notif-icon"></ion-icon>\r\n    </div>\r\n\r\n    <!-- \u{1F3EC} Vertical Scrollable Card List -->\r\n    <div class="cards-column">\r\n        <ion-card class="place-card">\r\n            <div class="image-container">\r\n                <img src="assets/img/ktc-nagar.jpeg" alt="Store" />\r\n            </div>\r\n\r\n            <ion-card-header>\r\n                <div class="card-header-row">\r\n                    <div class="card-info">\r\n                        <div class="title-row">\r\n                            <ion-icon name="storefront-outline" class="title-icon"></ion-icon>\r\n                            <ion-card-title>VPS KTC Nagar</ion-card-title>\r\n                        </div>\r\n                        <div class="subtitle-row">\r\n                            <ion-icon name="location" class="subtitle-icon"></ion-icon>\r\n                            <ion-card-subtitle>10km near</ion-card-subtitle>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <ion-button fill="outline" size="small" class="view-btn">\r\n                        View\r\n                    </ion-button>\r\n                </div>\r\n            </ion-card-header>\r\n        </ion-card>\r\n\r\n\r\n        <ion-card class="place-card">\r\n            <div class="image-container">\r\n                <img src="assets/img/market.jpeg" alt="Store" />\r\n            </div>\r\n\r\n            <ion-card-header>\r\n                <div class="card-header-row">\r\n                    <div class="card-info">\r\n                        <div class="title-row">\r\n                            <ion-icon name="storefront" class="title-icon"></ion-icon>\r\n                            <ion-card-title>VPS- Market</ion-card-title>\r\n                        </div>\r\n                        <div class="subtitle-row">\r\n                            <ion-icon name="location" class="subtitle-icon"></ion-icon>\r\n                            <ion-card-subtitle>15km near</ion-card-subtitle>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <ion-button fill="outline" size="small" class="view-btn">\r\n                        View\r\n                    </ion-button>\r\n                </div>\r\n            </ion-card-header>\r\n        </ion-card>\r\n\r\n        <ion-card class="place-card">\r\n            <div class="image-container">\r\n                <img src="assets/img/thachanallur.jpeg" alt="Store" />\r\n            </div>\r\n\r\n            <ion-card-header>\r\n                <div class="card-header-row">\r\n                    <div class="card-info">\r\n                        <div class="title-row">\r\n                            <ion-icon name="storefront" class="title-icon"></ion-icon>\r\n                            <ion-card-title>VPS KTC Nagar</ion-card-title>\r\n                        </div>\r\n                        <div class="subtitle-row">\r\n                            <ion-icon name="location" class="subtitle-icon"></ion-icon>\r\n                            <ion-card-subtitle>10km near</ion-card-subtitle>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <ion-button fill="outline" size="small" class="view-btn">\r\n                        View\r\n                    </ion-button>\r\n                </div>\r\n            </ion-card-header>\r\n        </ion-card>\r\n    </div>\r\n\r\n</ion-content>', styles: ['@charset "UTF-8";\n\n/* src/app/pages/user/store-details/store-details.scss */\n.store-page {\n  --background:\n    linear-gradient(\n      180deg,\n      #f7f9ff 0%,\n      #ffffff 100%);\n  display: flex;\n  flex-direction: column;\n  padding: 0;\n  overflow: hidden;\n}\n.top-bar {\n  position: sticky;\n  top: 0;\n  z-index: 10;\n  background: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 10px 14px;\n  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);\n  border-bottom-left-radius: 14px;\n  border-bottom-right-radius: 14px;\n}\n.search-box {\n  display: flex;\n  align-items: center;\n  background: #f1f3fa;\n  border-radius: 25px;\n  padding: 6px 14px;\n  flex: 1;\n  margin-right: 12px;\n  transition: all 0.3s ease-in-out;\n}\n.search-box input {\n  flex: 1;\n  border: none;\n  outline: none;\n  background: transparent;\n  font-size: 15px;\n  padding-left: 6px;\n  color: #333;\n}\n.search-box .search-icon {\n  font-size: 20px;\n  color: #555;\n}\n.search-box:focus-within {\n  background: #e7ebff;\n  box-shadow: 0 0 0 2px rgba(56, 128, 255, 0.2);\n}\n.notif-icon {\n  font-size: 24px;\n  color: #444;\n  cursor: pointer;\n  transition: transform 0.2s ease, color 0.2s ease;\n}\n.notif-icon:hover {\n  transform: scale(1.1);\n  color: #3880ff;\n}\n.cards-column {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  padding: 14px;\n  overflow-y: auto;\n  height: calc(100vh - 70px);\n  padding-bottom: 24px;\n}\n.place-card {\n  border-radius: 14px;\n  overflow: hidden;\n  background: #fff;\n  box-shadow: 0 6px 14px rgba(0, 0, 0, 0.08);\n  transition: transform 0.25s ease, box-shadow 0.25s ease;\n  flex: 0 0 auto;\n}\n.place-card img {\n  width: 100%;\n  height: 110px;\n  object-fit: cover;\n}\n.place-card ion-card-header {\n  padding: 10px 12px;\n}\n.place-card ion-card-header ion-card-title {\n  font-size: 16px;\n  font-weight: 600;\n  color: #222;\n}\n.place-card ion-card-header ion-card-subtitle {\n  font-size: 13px;\n  color: #666;\n}\n.place-card:hover {\n  transform: scale(1.02);\n  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);\n}\n.cards-column::-webkit-scrollbar {\n  width: 6px;\n}\n.cards-column::-webkit-scrollbar-thumb {\n  background: rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n}\n.place-card {\n  border-radius: 16px;\n  overflow: hidden;\n  background: #fff;\n  box-shadow: 0 6px 14px rgba(0, 0, 0, 0.08);\n  transition: transform 0.25s ease, box-shadow 0.25s ease;\n  margin-bottom: 14px;\n}\n.place-card:hover {\n  transform: scale(1.02);\n  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);\n}\n.image-container {\n  width: 100%;\n  height: 140px;\n  overflow: hidden;\n  position: relative;\n  border-bottom: 1px solid #eee;\n}\n.image-container img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  display: block;\n  transition: transform 0.3s ease;\n}\n.image-container:hover img {\n  transform: scale(1.05);\n}\n.card-header-row {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding-right: 6px;\n}\n.card-info {\n  display: flex;\n  flex-direction: column;\n}\n.card-info ion-card-title {\n  font-size: 16px;\n  font-weight: 600;\n  color: #222;\n  margin-bottom: 4px;\n}\n.card-info ion-card-subtitle {\n  font-size: 13px;\n  color: #666;\n}\n.view-btn {\n  --border-radius: 20px;\n  --padding-start: 12px;\n  --padding-end: 12px;\n  font-size: 13px;\n  font-weight: 500;\n  text-transform: none;\n  --border-color: #3880ff;\n  --color: #3880ff;\n  --ripple-color: rgba(56, 128, 255, 0.3);\n  transition: all 0.2s ease;\n}\n.view-btn:hover {\n  background: #3880ff;\n  color: #fff;\n}\n@media (max-width: 400px) {\n  .image-container {\n    height: 120px;\n  }\n}\n.place-card {\n  border-radius: 16px;\n  overflow: hidden;\n  background: #fff;\n  box-shadow: 0 6px 14px rgba(0, 0, 0, 0.08);\n  transition: transform 0.25s ease, box-shadow 0.25s ease;\n  margin-bottom: 14px;\n}\n.place-card:hover {\n  transform: scale(1.02);\n  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);\n}\n.image-container {\n  width: 100%;\n  height: 140px;\n  overflow: hidden;\n  position: relative;\n  border-bottom: 1px solid #eee;\n}\n.image-container img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  display: block;\n  transition: transform 0.3s ease;\n}\n.image-container:hover img {\n  transform: scale(1.05);\n}\n.card-header-row {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding-right: 6px;\n}\n.card-info {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.title-row {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.title-row .title-icon {\n  font-size: 18px;\n  color: #3880ff;\n}\n.title-row ion-card-title {\n  font-size: 16px;\n  font-weight: 600;\n  color: #222;\n}\n.subtitle-row {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.subtitle-row .subtitle-icon {\n  font-size: 16px;\n  color: #666;\n}\n.subtitle-row ion-card-subtitle {\n  font-size: 13px;\n  color: #666;\n}\n.view-btn {\n  --border-radius: 20px;\n  --padding-start: 12px;\n  --padding-end: 12px;\n  font-size: 13px;\n  font-weight: 500;\n  text-transform: none;\n  --border-color: #3880ff;\n  --color: #3880ff;\n  transition: all 0.2s ease;\n}\n.view-btn:hover {\n  background: #3880ff;\n  color: #fff;\n}\n@media (max-width: 400px) {\n  .image-container {\n    height: 120px;\n  }\n  ion-card-title {\n    font-size: 15px;\n  }\n}\n/*# sourceMappingURL=store-details.css.map */\n'] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(StoreDetails, { className: "StoreDetails", filePath: "src/app/pages/user/store-details/store-details.ts", lineNumber: 14 });
})();
export {
  StoreDetails
};
//# sourceMappingURL=store-details-OHMXQBQN.js.map
