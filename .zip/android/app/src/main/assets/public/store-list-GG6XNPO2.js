import {
  addOutline,
  arrowUndoCircleSharp,
  notificationsOutline,
  pencilOutline,
  trashOutline
} from "./chunk-TD74DZFV.js";
import {
  IonButton,
  IonContent,
  IonIcon
} from "./chunk-OIW4YKS2.js";
import {
  CommonModule,
  FormsModule
} from "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵtext
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/admin/store/store-list/store-list.ts
var _StoreList = class _StoreList {
  constructor() {
    this.stores = [
      {
        name: "VPS KTC Nagar",
        location: "10km near",
        status: "Active",
        image: "assets/img/ktc-nagar.jpeg"
      },
      {
        name: "VPS Market",
        location: "25km near",
        status: "Active",
        image: "assets/img/market.jpeg"
      },
      {
        name: "VPS Vanarapettai",
        location: "55km near",
        status: "Inactive",
        image: "assets/img/vanarapettai.jpeg"
      }
    ];
    addIcons({ addOutline, pencilOutline, trashOutline, notificationsOutline, arrowUndoCircleSharp });
  }
};
_StoreList.\u0275fac = function StoreList_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _StoreList)();
};
_StoreList.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _StoreList, selectors: [["app-store-list"]], decls: 88, vars: 0, consts: [[1, "booking-page"], [1, "top-header"], ["name", "arrow-undo-circle-sharp"], ["name", "notifications-outline"], [1, "booking-tabs"], [1, "active"], [1, "tab-wrapper"], [1, "booking-card"], [1, "booking-info"], ["name", "storefront-outline", 1, "service-icon"], [1, "details"], [1, "status", "Confirmed"], [1, "booking-action"], [1, "old-price"], [1, "price"], ["size", "small", "fill", "outline", "color", "primary"], [1, "status", "InProgress"], ["size", "small", "fill", "outline", "color", "medium"], [1, "status", "Completed"], ["size", "small", "fill", "outline", "color", "success"], [1, "status", "Cancelled"], ["size", "small", "fill", "outline", "color", "danger"]], template: function StoreList_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1);
    \u0275\u0275element(2, "ion-icon", 2);
    \u0275\u0275elementStart(3, "h2");
    \u0275\u0275text(4, "Store Bookings");
    \u0275\u0275elementEnd();
    \u0275\u0275element(5, "ion-icon", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 4)(7, "button", 5);
    \u0275\u0275text(8, "All");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "button");
    \u0275\u0275text(10, "Confirmed");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "button");
    \u0275\u0275text(12, "In Progress");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "button");
    \u0275\u0275text(14, "Completed");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "button");
    \u0275\u0275text(16, "Cancelled");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 6)(18, "div", 7)(19, "div", 8);
    \u0275\u0275element(20, "ion-icon", 9);
    \u0275\u0275elementStart(21, "div", 10)(22, "h4");
    \u0275\u0275text(23, "VPS KTC Nagar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "p");
    \u0275\u0275text(25, "Service: Hair Spa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "p");
    \u0275\u0275text(27, "Date: Oct 31, 2025");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "span", 11);
    \u0275\u0275text(29, "Confirmed");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(30, "div", 12)(31, "span", 13);
    \u0275\u0275text(32, "\u20B91200");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "span", 14);
    \u0275\u0275text(34, "\u20B9999");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "ion-button", 15);
    \u0275\u0275text(36, "View");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(37, "div", 7)(38, "div", 8);
    \u0275\u0275element(39, "ion-icon", 9);
    \u0275\u0275elementStart(40, "div", 10)(41, "h4");
    \u0275\u0275text(42, "VPS Market");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "p");
    \u0275\u0275text(44, "Service: Facial & Cleanup");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(45, "p");
    \u0275\u0275text(46, "Date: Oct 28, 2025");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "span", 16);
    \u0275\u0275text(48, "In Progress");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(49, "div", 12)(50, "span", 14);
    \u0275\u0275text(51, "\u20B9749");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(52, "ion-button", 17);
    \u0275\u0275text(53, "Track");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(54, "div", 7)(55, "div", 8);
    \u0275\u0275element(56, "ion-icon", 9);
    \u0275\u0275elementStart(57, "div", 10)(58, "h4");
    \u0275\u0275text(59, "VPS Thachanallur");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "p");
    \u0275\u0275text(61, "Service: Pedicure");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(62, "p");
    \u0275\u0275text(63, "Date: Oct 21, 2025");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(64, "span", 18);
    \u0275\u0275text(65, "Completed");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(66, "div", 12)(67, "span", 14);
    \u0275\u0275text(68, "\u20B9599");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "ion-button", 19);
    \u0275\u0275text(70, "Rebook");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(71, "div", 7)(72, "div", 8);
    \u0275\u0275element(73, "ion-icon", 9);
    \u0275\u0275elementStart(74, "div", 10)(75, "h4");
    \u0275\u0275text(76, "VPS Main Branch");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(77, "p");
    \u0275\u0275text(78, "Service: Hair Cut");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(79, "p");
    \u0275\u0275text(80, "Date: Oct 15, 2025");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(81, "span", 20);
    \u0275\u0275text(82, "Cancelled");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(83, "div", 12)(84, "span", 14);
    \u0275\u0275text(85, "\u20B9299");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(86, "ion-button", 21);
    \u0275\u0275text(87, "View");
    \u0275\u0275elementEnd()()()()();
  }
}, dependencies: [FormsModule, CommonModule, IonButton, IonContent, IonIcon], styles: ['@charset "UTF-8";\n\n\n\n.booking-page[_ngcontent-%COMP%] {\n  background: #fff;\n  min-height: 100vh;\n  overflow-y: auto;\n  display: flex;\n  flex-direction: column;\n}\n.booking-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%] {\n  position: sticky;\n  top: 0;\n  z-index: 10;\n  background: #fff;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 18px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);\n}\n.booking-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #2563eb;\n}\n.booking-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 700;\n  color: #111;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-around;\n  background: #f8f9fa;\n  padding: 10px 8px;\n  border-radius: 12px;\n  margin: 12px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.booking-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  flex: 1;\n  padding: 10px;\n  font-weight: 600;\n  color: #666;\n  border: none;\n  background: transparent;\n  transition: 0.3s ease;\n  border-radius: 8px;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%]   button.active[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      45deg,\n      #2563eb,\n      #60a5fa);\n  color: white;\n  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);\n}\n.booking-page[_ngcontent-%COMP%]   .tab-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  flex: 1;\n  overflow-y: auto;\n  padding-bottom: 80px;\n}\n.booking-page[_ngcontent-%COMP%]   .tab-pane[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  transition: transform 0.4s ease, opacity 0.3s ease;\n}\n.booking-page[_ngcontent-%COMP%]   .slide-in-left[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_slideInLeft 0.4s ease forwards;\n}\n.booking-page[_ngcontent-%COMP%]   .slide-in-right[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_slideInRight 0.4s ease forwards;\n}\n@keyframes _ngcontent-%COMP%_slideInLeft {\n  from {\n    transform: translateX(100%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(0);\n    opacity: 1;\n  }\n}\n@keyframes _ngcontent-%COMP%_slideInRight {\n  from {\n    transform: translateX(-100%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(0);\n    opacity: 1;\n  }\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%] {\n  background: #fff;\n  border-radius: 16px;\n  padding: 12px 14px;\n  margin: 12px;\n  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.07);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  transition: all 0.3s ease;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  flex: 1;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .service-icon[_ngcontent-%COMP%] {\n  font-size: 34px;\n  color: #2563eb;\n  margin-right: 12px;\n  background: #f0f4ff;\n  padding: 8px;\n  border-radius: 12px;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 600;\n  color: #111;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #666;\n  margin: 3px 0;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status[_ngcontent-%COMP%] {\n  font-size: 12px;\n  border-radius: 8px;\n  padding: 3px 8px;\n  font-weight: 600;\n  text-transform: capitalize;\n  display: inline-block;\n  margin-top: 4px;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.Confirmed[_ngcontent-%COMP%] {\n  background: #e0f2fe;\n  color: #0284c7;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.InProgress[_ngcontent-%COMP%] {\n  background: #fef9c3;\n  color: #ca8a04;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.Completed[_ngcontent-%COMP%] {\n  background: #dcfce7;\n  color: #16a34a;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.Cancelled[_ngcontent-%COMP%] {\n  background: #fee2e2;\n  color: #dc2626;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-action[_ngcontent-%COMP%] {\n  text-align: right;\n  min-width: 80px;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-action[_ngcontent-%COMP%]   .old-price[_ngcontent-%COMP%] {\n  text-decoration: line-through;\n  font-size: 12px;\n  color: #999;\n  display: block;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-action[_ngcontent-%COMP%]   .price[_ngcontent-%COMP%] {\n  font-weight: 700;\n  color: #111;\n  font-size: 14px;\n  display: block;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-action[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  margin-top: 4px;\n  font-size: 12px;\n  border-radius: 8px;\n  height: 28px;\n}\n/*# sourceMappingURL=store-list.css.map */'] });
var StoreList = _StoreList;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreList, [{
    type: Component,
    args: [{ selector: "app-store-list", imports: [FormsModule, CommonModule, IonButton, IonContent, IonIcon], template: '<ion-content class="booking-page">\r\n\r\n    <!-- \u{1F9ED} Top Header -->\r\n    <div class="top-header">\r\n        <ion-icon name="arrow-undo-circle-sharp"></ion-icon>\r\n        <h2>Store Bookings</h2>\r\n        <ion-icon name="notifications-outline"></ion-icon>\r\n    </div>\r\n\r\n    <!-- \u{1F4CB} Tabs (filter types of bookings) -->\r\n    <div class="booking-tabs">\r\n        <button class="active">All</button>\r\n        <button>Confirmed</button>\r\n        <button>In Progress</button>\r\n        <button>Completed</button>\r\n        <button>Cancelled</button>\r\n    </div>\r\n\r\n    <!-- \u{1F9F1} Booking Cards Wrapper -->\r\n    <div class="tab-wrapper">\r\n\r\n        <!-- \u{1FA84} Booking Card 1 -->\r\n        <div class="booking-card">\r\n            <div class="booking-info">\r\n                <ion-icon name="storefront-outline" class="service-icon"></ion-icon>\r\n                <div class="details">\r\n                    <h4>VPS KTC Nagar</h4>\r\n                    <p>Service: Hair Spa</p>\r\n                    <p>Date: Oct 31, 2025</p>\r\n                    <span class="status Confirmed">Confirmed</span>\r\n                </div>\r\n            </div>\r\n            <div class="booking-action">\r\n                <span class="old-price">\u20B91200</span>\r\n                <span class="price">\u20B9999</span>\r\n                <ion-button size="small" fill="outline" color="primary">View</ion-button>\r\n            </div>\r\n        </div>\r\n\r\n        <!-- Booking Card 2 -->\r\n        <div class="booking-card">\r\n            <div class="booking-info">\r\n                <ion-icon name="storefront-outline" class="service-icon"></ion-icon>\r\n                <div class="details">\r\n                    <h4>VPS Market</h4>\r\n                    <p>Service: Facial & Cleanup</p>\r\n                    <p>Date: Oct 28, 2025</p>\r\n                    <span class="status InProgress">In Progress</span>\r\n                </div>\r\n            </div>\r\n            <div class="booking-action">\r\n                <span class="price">\u20B9749</span>\r\n                <ion-button size="small" fill="outline" color="medium">Track</ion-button>\r\n            </div>\r\n        </div>\r\n\r\n        <!-- Booking Card 3 -->\r\n        <div class="booking-card">\r\n            <div class="booking-info">\r\n                <ion-icon name="storefront-outline" class="service-icon"></ion-icon>\r\n                <div class="details">\r\n                    <h4>VPS Thachanallur</h4>\r\n                    <p>Service: Pedicure</p>\r\n                    <p>Date: Oct 21, 2025</p>\r\n                    <span class="status Completed">Completed</span>\r\n                </div>\r\n            </div>\r\n            <div class="booking-action">\r\n                <span class="price">\u20B9599</span>\r\n                <ion-button size="small" fill="outline" color="success">Rebook</ion-button>\r\n            </div>\r\n        </div>\r\n\r\n        <!-- Booking Card 4 -->\r\n        <div class="booking-card">\r\n            <div class="booking-info">\r\n                <ion-icon name="storefront-outline" class="service-icon"></ion-icon>\r\n                <div class="details">\r\n                    <h4>VPS Main Branch</h4>\r\n                    <p>Service: Hair Cut</p>\r\n                    <p>Date: Oct 15, 2025</p>\r\n                    <span class="status Cancelled">Cancelled</span>\r\n                </div>\r\n            </div>\r\n            <div class="booking-action">\r\n                <span class="price">\u20B9299</span>\r\n                <ion-button size="small" fill="outline" color="danger">View</ion-button>\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n\r\n</ion-content>', styles: ['@charset "UTF-8";\n\n/* src/app/pages/admin/store/store-list/store-list.scss */\n.booking-page {\n  background: #fff;\n  min-height: 100vh;\n  overflow-y: auto;\n  display: flex;\n  flex-direction: column;\n}\n.booking-page .top-header {\n  position: sticky;\n  top: 0;\n  z-index: 10;\n  background: #fff;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 18px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);\n}\n.booking-page .top-header ion-icon {\n  font-size: 24px;\n  color: #2563eb;\n}\n.booking-page .top-header h2 {\n  font-size: 18px;\n  font-weight: 700;\n  color: #111;\n}\n.booking-page .booking-tabs {\n  display: flex;\n  justify-content: space-around;\n  background: #f8f9fa;\n  padding: 10px 8px;\n  border-radius: 12px;\n  margin: 12px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.booking-page .booking-tabs button {\n  flex: 1;\n  padding: 10px;\n  font-weight: 600;\n  color: #666;\n  border: none;\n  background: transparent;\n  transition: 0.3s ease;\n  border-radius: 8px;\n}\n.booking-page .booking-tabs button.active {\n  background:\n    linear-gradient(\n      45deg,\n      #2563eb,\n      #60a5fa);\n  color: white;\n  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);\n}\n.booking-page .tab-wrapper {\n  position: relative;\n  flex: 1;\n  overflow-y: auto;\n  padding-bottom: 80px;\n}\n.booking-page .tab-pane {\n  position: relative;\n  width: 100%;\n  transition: transform 0.4s ease, opacity 0.3s ease;\n}\n.booking-page .slide-in-left {\n  animation: slideInLeft 0.4s ease forwards;\n}\n.booking-page .slide-in-right {\n  animation: slideInRight 0.4s ease forwards;\n}\n@keyframes slideInLeft {\n  from {\n    transform: translateX(100%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(0);\n    opacity: 1;\n  }\n}\n@keyframes slideInRight {\n  from {\n    transform: translateX(-100%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(0);\n    opacity: 1;\n  }\n}\n.booking-page .booking-card {\n  background: #fff;\n  border-radius: 16px;\n  padding: 12px 14px;\n  margin: 12px;\n  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.07);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  transition: all 0.3s ease;\n}\n.booking-page .booking-card:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);\n}\n.booking-page .booking-card .booking-info {\n  display: flex;\n  align-items: center;\n  flex: 1;\n}\n.booking-page .booking-card .booking-info .service-icon {\n  font-size: 34px;\n  color: #2563eb;\n  margin-right: 12px;\n  background: #f0f4ff;\n  padding: 8px;\n  border-radius: 12px;\n}\n.booking-page .booking-card .booking-info .details h4 {\n  font-size: 15px;\n  font-weight: 600;\n  color: #111;\n}\n.booking-page .booking-card .booking-info .details p {\n  font-size: 13px;\n  color: #666;\n  margin: 3px 0;\n}\n.booking-page .booking-card .booking-info .details .status {\n  font-size: 12px;\n  border-radius: 8px;\n  padding: 3px 8px;\n  font-weight: 600;\n  text-transform: capitalize;\n  display: inline-block;\n  margin-top: 4px;\n}\n.booking-page .booking-card .booking-info .details .status.Confirmed {\n  background: #e0f2fe;\n  color: #0284c7;\n}\n.booking-page .booking-card .booking-info .details .status.InProgress {\n  background: #fef9c3;\n  color: #ca8a04;\n}\n.booking-page .booking-card .booking-info .details .status.Completed {\n  background: #dcfce7;\n  color: #16a34a;\n}\n.booking-page .booking-card .booking-info .details .status.Cancelled {\n  background: #fee2e2;\n  color: #dc2626;\n}\n.booking-page .booking-card .booking-action {\n  text-align: right;\n  min-width: 80px;\n}\n.booking-page .booking-card .booking-action .old-price {\n  text-decoration: line-through;\n  font-size: 12px;\n  color: #999;\n  display: block;\n}\n.booking-page .booking-card .booking-action .price {\n  font-weight: 700;\n  color: #111;\n  font-size: 14px;\n  display: block;\n}\n.booking-page .booking-card .booking-action ion-button {\n  margin-top: 4px;\n  font-size: 12px;\n  border-radius: 8px;\n  height: 28px;\n}\n/*# sourceMappingURL=store-list.css.map */\n'] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(StoreList, { className: "StoreList", filePath: "src/app/pages/admin/store/store-list/store-list.ts", lineNumber: 15 });
})();
export {
  StoreList
};
//# sourceMappingURL=store-list-GG6XNPO2.js.map
