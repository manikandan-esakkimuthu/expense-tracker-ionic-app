import {
  IonContent,
  IonHeader,
  IonIcon,
  IonToolbar,
  IonicModule
} from "./chunk-PBX6UFXU.js";
import {
  arrowDownOutline,
  arrowUpOutline,
  ellipsisHorizontalOutline,
  gridOutline,
  notificationsOutline
} from "./chunk-TD74DZFV.js";
import {
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgForOf
} from "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate2
} from "./chunk-NPNYO6CD.js";
import "./chunk-4625MWOI.js";
import "./chunk-W7NNY2EY.js";
import "./chunk-LT3LEW4O.js";
import "./chunk-TH3NAJYP.js";
import "./chunk-XOTLEQNJ.js";
import "./chunk-UMTFGNU2.js";
import "./chunk-RCMGGQIF.js";
import "./chunk-6YCZ7XWX.js";
import "./chunk-YZJQZ23Y.js";
import "./chunk-6TWGLSWA.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-CXDFQPX7.js";
import "./chunk-DFAOHKQG.js";
import "./chunk-F3JJ4YWB.js";
import "./chunk-QOQL43QQ.js";
import "./chunk-5YIQV2FO.js";
import "./chunk-IVBL4Y7V.js";
import "./chunk-NNTRQ7Y2.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/expense/users/user-dashboard/user-dashboard.ts
function UserDashboard_div_34_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 20)(1, "div", 21);
    \u0275\u0275element(2, "img", 22);
    \u0275\u0275elementStart(3, "div")(4, "h6", 23);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "small", 24);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(8, "div", 25);
    \u0275\u0275text(9);
    \u0275\u0275pipe(10, "currency");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const t_r1 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("src", t_r1.icon, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(t_r1.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(t_r1.time);
    \u0275\u0275advance();
    \u0275\u0275property("ngClass", t_r1.amount > 0 ? "text-success" : "text-danger");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2(" ", t_r1.amount > 0 ? "+" : "", "", \u0275\u0275pipeBind2(10, 6, t_r1.amount, "USD"), " ");
  }
}
var _UserDashboard = class _UserDashboard {
  constructor() {
    this.transactions = [
      { title: "Salary", time: "Today", amount: 2350, icon: "assets/icons/income.png" },
      { title: "Shopping", time: "Yesterday", amount: -120, icon: "assets/icons/expense.png" },
      { title: "Groceries", time: "2 days ago", amount: -80, icon: "assets/icons/expense2.png" }
    ];
    addIcons({ gridOutline, notificationsOutline, ellipsisHorizontalOutline, arrowDownOutline, arrowUpOutline });
  }
};
_UserDashboard.\u0275fac = function UserDashboard_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _UserDashboard)();
};
_UserDashboard.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _UserDashboard, selectors: [["app-user-dashboard"]], decls: 35, vars: 2, consts: [["translucent", "true"], [1, "px-3", "py-2"], [1, "d-flex", "justify-content-between", "align-items-center", "w-100"], ["name", "grid-outline", "size", "large", 1, "text-dark"], [1, "m-0", "fw-bold", "flex-grow-1", "text-center"], ["name", "notifications-outline", "size", "large", 1, "text-dark"], [1, "home-content", 3, "fullscreen"], [1, "balance-card", "mx-3", "mt-3", "p-3", "rounded-4", "shadow-sm", "text-white"], [1, "d-flex", "justify-content-between", "align-items-center"], ["name", "ellipsis-horizontal-outline"], [1, "fw-bold", "mt-2"], [1, "d-flex", "justify-content-between", "mt-3"], ["name", "arrow-down-outline"], [1, "ms-1"], [1, "fw-bold"], ["name", "arrow-up-outline"], [1, "transactions", "mt-4", "px-3"], [1, "d-flex", "justify-content-between", "align-items-center", "mb-2"], [1, "text-primary", "small"], ["class", "transaction-item d-flex justify-content-between align-items-center py-2", 4, "ngFor", "ngForOf"], [1, "transaction-item", "d-flex", "justify-content-between", "align-items-center", "py-2"], [1, "d-flex", "align-items-center"], ["alt", "icon", "width", "35", "height", "35", 1, "me-2", "rounded-circle", 3, "src"], [1, "m-0", "fw-bold"], [1, "text-muted"], [1, "fw-bold", 3, "ngClass"]], template: function UserDashboard_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2);
    \u0275\u0275element(3, "ion-icon", 3);
    \u0275\u0275elementStart(4, "h5", 4);
    \u0275\u0275text(5, "Home");
    \u0275\u0275elementEnd();
    \u0275\u0275element(6, "ion-icon", 5);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 6)(8, "div", 7)(9, "div", 8)(10, "span");
    \u0275\u0275text(11, "Total Balance");
    \u0275\u0275elementEnd();
    \u0275\u0275element(12, "ion-icon", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "h2", 10);
    \u0275\u0275text(14, "$3,257.00");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "div", 11)(16, "div");
    \u0275\u0275element(17, "ion-icon", 12);
    \u0275\u0275elementStart(18, "span", 13);
    \u0275\u0275text(19, "Income");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "h6", 14);
    \u0275\u0275text(21, "$2,350.00");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div");
    \u0275\u0275element(23, "ion-icon", 15);
    \u0275\u0275elementStart(24, "span", 13);
    \u0275\u0275text(25, "Expenses");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "h6", 14);
    \u0275\u0275text(27, "$950.00");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(28, "div", 16)(29, "div", 17)(30, "h5", 14);
    \u0275\u0275text(31, "Transactions");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "span", 18);
    \u0275\u0275text(33, "See All");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(34, UserDashboard_div_34_Template, 11, 9, "div", 19);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(27);
    \u0275\u0275property("ngForOf", ctx.transactions);
  }
}, dependencies: [CommonModule, NgClass, NgForOf, IonicModule, IonContent, IonHeader, IonIcon, IonToolbar, CurrencyPipe], styles: ["\n\n.home-content[_ngcontent-%COMP%] {\n  --background: #f8f8ff;\n  padding-bottom: 80px;\n}\n.balance-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #6a11cb,\n      #2575fc);\n}\n.transaction-item[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #eee;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --min-height: 60px;\n  border-bottom: 1px solid #eee;\n}\nion-toolbar[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\nion-toolbar[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 600;\n  color: #000;\n}\n/*# sourceMappingURL=user-dashboard.css.map */"] });
var UserDashboard = _UserDashboard;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserDashboard, [{
    type: Component,
    args: [{ selector: "app-user-dashboard", imports: [CommonModule, CurrencyPipe, IonicModule], template: `<ion-header translucent="true">\r
    <ion-toolbar class="px-3 py-2">\r
        <div class="d-flex justify-content-between align-items-center w-100">\r
\r
            <!-- Left: Menu Icon -->\r
            <ion-icon name="grid-outline" size="large" class="text-dark"></ion-icon>\r
\r
            <!-- Center: Title -->\r
            <h5 class="m-0 fw-bold flex-grow-1 text-center">Home</h5>\r
\r
            <!-- Right: Notification Icon -->\r
            <ion-icon name="notifications-outline" size="large" class="text-dark"></ion-icon>\r
\r
        </div>\r
    </ion-toolbar>\r
</ion-header>\r
\r
\r
<ion-content [fullscreen]="true" class="home-content">\r
\r
    <!-- Balance Card -->\r
    <div class="balance-card mx-3 mt-3 p-3 rounded-4 shadow-sm text-white">\r
        <div class="d-flex justify-content-between align-items-center">\r
            <span>Total Balance</span>\r
            <ion-icon name="ellipsis-horizontal-outline"></ion-icon>\r
        </div>\r
        <h2 class="fw-bold mt-2">$3,257.00</h2>\r
\r
        <div class="d-flex justify-content-between mt-3">\r
            <div>\r
                <ion-icon name="arrow-down-outline"></ion-icon>\r
                <span class="ms-1">Income</span>\r
                <h6 class="fw-bold">$2,350.00</h6>\r
            </div>\r
            <div>\r
                <ion-icon name="arrow-up-outline"></ion-icon>\r
                <span class="ms-1">Expenses</span>\r
                <h6 class="fw-bold">$950.00</h6>\r
            </div>\r
        </div>\r
    </div>\r
\r
    <!-- Transactions List -->\r
    <div class="transactions mt-4 px-3">\r
        <div class="d-flex justify-content-between align-items-center mb-2">\r
            <h5 class="fw-bold">Transactions</h5>\r
            <span class="text-primary small">See All</span>\r
        </div>\r
\r
        <div *ngFor="let t of transactions"\r
            class="transaction-item d-flex justify-content-between align-items-center py-2">\r
            <div class="d-flex align-items-center">\r
                <img [src]="t.icon" alt="icon" class="me-2 rounded-circle" width="35" height="35">\r
                <div>\r
                    <h6 class="m-0 fw-bold">{{t.title}}</h6>\r
                    <small class="text-muted">{{t.time}}</small>\r
                </div>\r
            </div>\r
            <div [ngClass]="t.amount > 0 ? 'text-success' : 'text-danger'" class="fw-bold">\r
                {{t.amount > 0 ? '+' : ''}}{{t.amount | currency:'USD'}}\r
            </div>\r
        </div>\r
    </div>\r
\r
</ion-content>`, styles: ["/* src/app/pages/expense/users/user-dashboard/user-dashboard.scss */\n.home-content {\n  --background: #f8f8ff;\n  padding-bottom: 80px;\n}\n.balance-card {\n  background:\n    linear-gradient(\n      135deg,\n      #6a11cb,\n      #2575fc);\n}\n.transaction-item {\n  border-bottom: 1px solid #eee;\n}\nion-toolbar {\n  --background: #ffffff;\n  --min-height: 60px;\n  border-bottom: 1px solid #eee;\n}\nion-toolbar ion-icon {\n  cursor: pointer;\n}\nion-toolbar h5 {\n  font-size: 18px;\n  font-weight: 600;\n  color: #000;\n}\n/*# sourceMappingURL=user-dashboard.css.map */\n"] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(UserDashboard, { className: "UserDashboard", filePath: "src/app/pages/expense/users/user-dashboard/user-dashboard.ts", lineNumber: 14 });
})();
export {
  UserDashboard
};
//# sourceMappingURL=user-dashboard-V4U7BSMJ.js.map
