import {
  iosTransitionAnimation,
  shadow
} from "./chunk-4DFKN73H.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";
export {
  iosTransitionAnimation,
  shadow
};
//# sourceMappingURL=ios.transition-3GGRKTGY.js.map
