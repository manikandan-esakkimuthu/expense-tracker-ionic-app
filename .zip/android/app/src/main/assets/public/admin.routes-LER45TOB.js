import {
  homeOutline,
  peopleOutline,
  personCircleOutline,
  settingsOutline,
  storefrontOutline
} from "./chunk-TD74DZFV.js";
import {
  IonIcon,
  IonLabel,
  IonTabBar,
  IonTabButton,
  IonTabs
} from "./chunk-OIW4YKS2.js";
import "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵtext
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/admin-tabs/admin-tabs.ts
var _AdminTabs = class _AdminTabs {
  constructor() {
    addIcons({ homeOutline, storefrontOutline, peopleOutline, personCircleOutline, settingsOutline });
  }
};
_AdminTabs.\u0275fac = function AdminTabs_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AdminTabs)();
};
_AdminTabs.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AdminTabs, selectors: [["app-admin-tabs"]], decls: 22, vars: 0, consts: [["slot", "bottom", 1, "admin-tab-bar"], ["tab", "dashboard"], ["name", "home-outline"], ["tab", "admin-store"], ["name", "storefront-outline"], ["tab", "employees"], ["name", "people-outline"], ["tab", "customer"], ["name", "person-circle-outline"], ["tab", "settings"], ["name", "settings-outline"]], template: function AdminTabs_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-tabs")(1, "ion-tab-bar", 0)(2, "ion-tab-button", 1);
    \u0275\u0275element(3, "ion-icon", 2);
    \u0275\u0275elementStart(4, "ion-label");
    \u0275\u0275text(5, "Dashboard");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "ion-tab-button", 3);
    \u0275\u0275element(7, "ion-icon", 4);
    \u0275\u0275elementStart(8, "ion-label");
    \u0275\u0275text(9, "Stores");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "ion-tab-button", 5);
    \u0275\u0275element(11, "ion-icon", 6);
    \u0275\u0275elementStart(12, "ion-label");
    \u0275\u0275text(13, "Employees");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "ion-tab-button", 7);
    \u0275\u0275element(15, "ion-icon", 8);
    \u0275\u0275elementStart(16, "ion-label");
    \u0275\u0275text(17, "Users");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "ion-tab-button", 9);
    \u0275\u0275element(19, "ion-icon", 10);
    \u0275\u0275elementStart(20, "ion-label");
    \u0275\u0275text(21, "Settings");
    \u0275\u0275elementEnd()()()();
  }
}, dependencies: [IonTabButton, IonIcon, IonLabel, IonTabs, IonTabBar], encapsulation: 2 });
var AdminTabs = _AdminTabs;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AdminTabs, [{
    type: Component,
    args: [{ selector: "app-admin-tabs", imports: [IonTabButton, IonIcon, IonLabel, IonTabs, IonTabBar], template: '<ion-tabs>\r\n    <ion-tab-bar slot="bottom" class="admin-tab-bar">\r\n        <ion-tab-button tab="dashboard">\r\n            <ion-icon name="home-outline"></ion-icon>\r\n            <ion-label>Dashboard</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="admin-store">\r\n            <ion-icon name="storefront-outline"></ion-icon>\r\n            <ion-label>Stores</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="employees">\r\n            <ion-icon name="people-outline"></ion-icon>\r\n            <ion-label>Employees</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="customer">\r\n            <ion-icon name="person-circle-outline"></ion-icon>\r\n            <ion-label>Users</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="settings">\r\n            <ion-icon name="settings-outline"></ion-icon>\r\n            <ion-label>Settings</ion-label>\r\n        </ion-tab-button>\r\n    </ion-tab-bar>\r\n</ion-tabs>' }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AdminTabs, { className: "AdminTabs", filePath: "src/app/pages/admin-tabs/admin-tabs.ts", lineNumber: 11 });
})();

// src/app/pages/admin/admin.routes.ts
var ADMIN_ROUTES = [
  {
    path: "",
    component: AdminTabs,
    children: [
      // 🧭 Admin Dashboard — default first page
      {
        path: "dashboard",
        loadComponent: () => import("./admin-dashboard-PKSX7UZM.js").then((m) => m.AdminDashboard)
      },
      // 🏬 Store Management
      {
        path: "admin-store",
        loadComponent: () => import("./store-list-GG6XNPO2.js").then((m) => m.StoreList)
      },
      {
        path: "employees",
        loadComponent: () => import("./employee-list-QSLJQKW3.js").then((m) => m.EmployeeList)
      },
      {
        path: "customer",
        loadComponent: () => import("./admin-customer-list-P7MBYHBQ.js").then((m) => m.AdminCustomerList)
      },
      // 👉 Default redirect to dashboard
      {
        path: "",
        redirectTo: "dashboard",
        pathMatch: "full"
      }
    ]
  }
];
export {
  ADMIN_ROUTES
};
//# sourceMappingURL=admin.routes-LER45TOB.js.map
