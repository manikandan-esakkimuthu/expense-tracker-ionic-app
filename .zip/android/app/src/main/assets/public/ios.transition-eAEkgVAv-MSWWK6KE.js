import {
  iosTransitionAnimation,
  shadow
} from "./chunk-RCMGGQIF.js";
import "./chunk-YZJQZ23Y.js";
import "./chunk-6TWGLSWA.js";
import "./chunk-DFAOHKQG.js";
import "./chunk-IVBL4Y7V.js";
import "./chunk-NNTRQ7Y2.js";
import "./chunk-EAE2VPRF.js";
export {
  iosTransitionAnimation,
  shadow
};
//# sourceMappingURL=ios.transition-eAEkgVAv-MSWWK6KE.js.map
