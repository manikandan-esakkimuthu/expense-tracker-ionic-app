import {
  arrowUndoCircleSharp,
  batteryChargingOutline,
  bicycleOutline,
  buildOutline,
  bulbOutline,
  carSportOutline,
  clipboardOutline,
  constructOutline,
  flashOutline,
  notificationsOutline,
  searchOutline,
  settingsOutline,
  sparklesOutline,
  speedometerOutline
} from "./chunk-TD74DZFV.js";
import {
  IonButton,
  IonContent,
  IonIcon
} from "./chunk-OIW4YKS2.js";
import {
  CommonModule,
  FormsModule,
  NgClass,
  NgForOf,
  NgIf
} from "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/user/mybooking-details/mybooking-details.ts
function MybookingDetails_div_12_div_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 11)(1, "div", 12);
    \u0275\u0275element(2, "ion-icon", 13);
    \u0275\u0275elementStart(3, "div", 14)(4, "h4");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 15);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 16)(11, "span", 17);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 18);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "ion-button", 19);
    \u0275\u0275text(16, "Book Again");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const booking_r1 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("name", booking_r1.icon);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(booking_r1.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", booking_r1.date, " | ", booking_r1.time);
    \u0275\u0275advance();
    \u0275\u0275property("ngClass", booking_r1.status);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(booking_r1.status);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", booking_r1.originalPrice);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", booking_r1.discountPrice);
  }
}
function MybookingDetails_div_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 9);
    \u0275\u0275template(1, MybookingDetails_div_12_div_1_Template, 17, 8, "div", 10);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275classProp("slide-in-left", ctx_r1.activeTab === "active" && ctx_r1.lastTab === "past")("slide-in-right", ctx_r1.activeTab === "active" && ctx_r1.lastTab === "active");
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r1.activeBookings);
  }
}
function MybookingDetails_div_13_div_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 21)(1, "div", 12);
    \u0275\u0275element(2, "ion-icon", 13);
    \u0275\u0275elementStart(3, "div", 14)(4, "h4");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 22);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 16)(11, "span", 17);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 18);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "ion-button", 23);
    \u0275\u0275text(16, "Rebook");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const booking_r3 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("name", booking_r3.icon);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(booking_r3.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", booking_r3.date, " | ", booking_r3.time);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(booking_r3.status);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", booking_r3.originalPrice);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", booking_r3.discountPrice);
  }
}
function MybookingDetails_div_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 9);
    \u0275\u0275template(1, MybookingDetails_div_13_div_1_Template, 17, 7, "div", 20);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275classProp("slide-in-right", ctx_r1.activeTab === "past" && ctx_r1.lastTab === "active")("slide-in-left", ctx_r1.activeTab === "past" && ctx_r1.lastTab === "past");
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r1.pastBookings);
  }
}
var _MybookingDetails = class _MybookingDetails {
  constructor() {
    this.activeTab = "active";
    this.lastTab = "active";
    this.activeBookings = [
      { name: "Engine Oil & Filter", icon: "construct-outline", date: "31 Oct", time: "11:00 AM", status: "Confirmed", originalPrice: 699, discountPrice: 499 },
      { name: "Bike Wash", icon: "sparkles-outline", date: "1 Nov", time: "9:30 AM", status: "InProgress", originalPrice: 299, discountPrice: 249 }
    ];
    this.pastBookings = [
      { name: "Chain Lubrication", icon: "speedometer-outline", date: "28 Oct", time: "2:00 PM", status: "Completed", originalPrice: 249, discountPrice: 199 }
    ];
    addIcons({
      arrowUndoCircleSharp,
      notificationsOutline,
      searchOutline,
      speedometerOutline,
      sparklesOutline,
      constructOutline,
      bicycleOutline,
      settingsOutline,
      flashOutline,
      carSportOutline,
      buildOutline,
      batteryChargingOutline,
      bulbOutline,
      clipboardOutline
    });
  }
  switchTab(tab) {
    this.lastTab = this.activeTab;
    this.activeTab = tab;
  }
};
_MybookingDetails.\u0275fac = function MybookingDetails_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _MybookingDetails)();
};
_MybookingDetails.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _MybookingDetails, selectors: [["app-mybooking-details"]], decls: 14, vars: 6, consts: [[1, "booking-page"], [1, "top-header"], ["name", "arrow-undo-circle-sharp", 1, "back-icon"], ["name", "notifications-outline", 1, "notif-icon"], [1, "booking-tabs"], [3, "click"], [1, "tab-wrapper"], ["class", "tab-pane", 3, "slide-in-left", "slide-in-right", 4, "ngIf"], ["class", "tab-pane", 3, "slide-in-right", "slide-in-left", 4, "ngIf"], [1, "tab-pane"], ["class", "booking-card", 4, "ngFor", "ngForOf"], [1, "booking-card"], [1, "booking-info"], [1, "service-icon", 3, "name"], [1, "details"], [1, "status", 3, "ngClass"], [1, "booking-action"], [1, "old-price"], [1, "price"], ["fill", "solid", "color", "primary", "size", "small", 1, "view-btn"], ["class", "booking-card past", 4, "ngFor", "ngForOf"], [1, "booking-card", "past"], [1, "status", "completed"], ["fill", "outline", "color", "primary", "size", "small", 1, "rebook-btn"]], template: function MybookingDetails_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1);
    \u0275\u0275element(2, "ion-icon", 2);
    \u0275\u0275elementStart(3, "h2");
    \u0275\u0275text(4, "My Bookings");
    \u0275\u0275elementEnd();
    \u0275\u0275element(5, "ion-icon", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 4)(7, "button", 5);
    \u0275\u0275listener("click", function MybookingDetails_Template_button_click_7_listener() {
      return ctx.switchTab("active");
    });
    \u0275\u0275text(8, "Active");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "button", 5);
    \u0275\u0275listener("click", function MybookingDetails_Template_button_click_9_listener() {
      return ctx.switchTab("past");
    });
    \u0275\u0275text(10, "Past");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 6);
    \u0275\u0275template(12, MybookingDetails_div_12_Template, 2, 5, "div", 7)(13, MybookingDetails_div_13_Template, 2, 5, "div", 8);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275classProp("active", ctx.activeTab === "active");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.activeTab === "past");
    \u0275\u0275advance(3);
    \u0275\u0275property("ngIf", ctx.activeTab === "active");
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx.activeTab === "past");
  }
}, dependencies: [IonButton, IonIcon, IonContent, FormsModule, CommonModule, NgClass, NgForOf, NgIf], styles: ["\n\n.booking-page[_ngcontent-%COMP%] {\n  background: #f6f8fb;\n  min-height: 100%;\n}\n.booking-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%] {\n  position: sticky;\n  top: 0;\n  z-index: 10;\n  background: white;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 18px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.booking-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #3b82f6;\n}\n.booking-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 600;\n  color: #111;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-around;\n  background: #fff;\n  padding: 10px 0;\n  border-radius: 12px;\n  margin: 12px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.booking-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  flex: 1;\n  padding: 10px;\n  font-weight: 600;\n  color: #666;\n  border: none;\n  background: transparent;\n  transition: 0.3s;\n  border-radius: 8px;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%]   button.active[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      45deg,\n      #2563eb,\n      #60a5fa);\n  color: white;\n  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);\n}\n.booking-page[_ngcontent-%COMP%]   .tab-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  overflow: hidden;\n  min-height: 400px;\n}\n.booking-page[_ngcontent-%COMP%]   .tab-pane[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 100%;\n  transition: transform 0.4s ease, opacity 0.3s ease;\n}\n.booking-page[_ngcontent-%COMP%]   .slide-in-left[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_slideInLeft 0.4s ease forwards;\n}\n.booking-page[_ngcontent-%COMP%]   .slide-in-right[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_slideInRight 0.4s ease forwards;\n}\n@keyframes _ngcontent-%COMP%_slideInLeft {\n  from {\n    transform: translateX(100%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(0);\n    opacity: 1;\n  }\n}\n@keyframes _ngcontent-%COMP%_slideInRight {\n  from {\n    transform: translateX(-100%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(0);\n    opacity: 1;\n  }\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%] {\n  background: white;\n  border-radius: 15px;\n  padding: 12px;\n  margin: 12px;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  transition: transform 0.3s ease;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]:hover {\n  transform: scale(1.02);\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .service-icon[_ngcontent-%COMP%] {\n  font-size: 34px;\n  color: #2563eb;\n  margin-right: 12px;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 600;\n  color: #111;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #666;\n  margin: 3px 0;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status[_ngcontent-%COMP%] {\n  font-size: 12px;\n  border-radius: 8px;\n  padding: 3px 8px;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.Confirmed[_ngcontent-%COMP%] {\n  background: #e0f2fe;\n  color: #0284c7;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.InProgress[_ngcontent-%COMP%] {\n  background: #fef9c3;\n  color: #ca8a04;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.Completed[_ngcontent-%COMP%] {\n  background: #dcfce7;\n  color: #16a34a;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.Cancelled[_ngcontent-%COMP%] {\n  background: #fee2e2;\n  color: #dc2626;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-action[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-action[_ngcontent-%COMP%]   .old-price[_ngcontent-%COMP%] {\n  text-decoration: line-through;\n  font-size: 12px;\n  color: #999;\n  display: block;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-action[_ngcontent-%COMP%]   .price[_ngcontent-%COMP%] {\n  font-weight: 700;\n  color: #111;\n  font-size: 14px;\n  display: block;\n}\n.booking-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .booking-action[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  margin-top: 4px;\n  font-size: 12px;\n  border-radius: 8px;\n}\n/*# sourceMappingURL=mybooking-details.css.map */"] });
var MybookingDetails = _MybookingDetails;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MybookingDetails, [{
    type: Component,
    args: [{ selector: "app-mybooking-details", imports: [IonButton, IonIcon, IonContent, FormsModule, CommonModule], template: `<ion-content class="booking-page">\r
\r
    <!-- \u{1F51D} Header -->\r
    <div class="top-header">\r
        <ion-icon name="arrow-undo-circle-sharp" class="back-icon"></ion-icon>\r
        <h2>My Bookings</h2>\r
        <ion-icon name="notifications-outline" class="notif-icon"></ion-icon>\r
    </div>\r
\r
    <!-- \u{1F9ED} Tabs -->\r
    <div class="booking-tabs">\r
        <button [class.active]="activeTab === 'active'" (click)="switchTab('active')">Active</button>\r
        <button [class.active]="activeTab === 'past'" (click)="switchTab('past')">Past</button>\r
    </div>\r
\r
    <!-- \u{1F4CB} Tab Content Container -->\r
    <div class="tab-wrapper">\r
\r
        <!-- \u{1F7E2} Active Bookings -->\r
        <div class="tab-pane" [class.slide-in-left]="activeTab === 'active' && lastTab === 'past'"\r
            [class.slide-in-right]="activeTab === 'active' && lastTab === 'active'" *ngIf="activeTab === 'active'">\r
            <div *ngFor="let booking of activeBookings" class="booking-card">\r
                <div class="booking-info">\r
                    <ion-icon [name]="booking.icon" class="service-icon"></ion-icon>\r
                    <div class="details">\r
                        <h4>{{ booking.name }}</h4>\r
                        <p>{{ booking.date }} | {{ booking.time }}</p>\r
                        <span class="status" [ngClass]="booking.status">{{ booking.status }}</span>\r
                    </div>\r
                </div>\r
                <div class="booking-action">\r
                    <span class="old-price">\u20B9{{ booking.originalPrice }}</span>\r
                    <span class="price">\u20B9{{ booking.discountPrice }}</span>\r
                    <ion-button fill="solid" color="primary" size="small" class="view-btn">Book Again</ion-button>\r
                </div>\r
            </div>\r
        </div>\r
\r
        <!-- \u{1F552} Past Bookings -->\r
        <div class="tab-pane" [class.slide-in-right]="activeTab === 'past' && lastTab === 'active'"\r
            [class.slide-in-left]="activeTab === 'past' && lastTab === 'past'" *ngIf="activeTab === 'past'">\r
            <div *ngFor="let booking of pastBookings" class="booking-card past">\r
                <div class="booking-info">\r
                    <ion-icon [name]="booking.icon" class="service-icon"></ion-icon>\r
                    <div class="details">\r
                        <h4>{{ booking.name }}</h4>\r
                        <p>{{ booking.date }} | {{ booking.time }}</p>\r
                        <span class="status completed">{{ booking.status }}</span>\r
                    </div>\r
                </div>\r
                <div class="booking-action">\r
                    <span class="old-price">\u20B9{{ booking.originalPrice }}</span>\r
                    <span class="price">\u20B9{{ booking.discountPrice }}</span>\r
                    <ion-button fill="outline" color="primary" size="small" class="rebook-btn">Rebook</ion-button>\r
                </div>\r
            </div>\r
        </div>\r
\r
    </div>\r
</ion-content>`, styles: ["/* src/app/pages/user/mybooking-details/mybooking-details.scss */\n.booking-page {\n  background: #f6f8fb;\n  min-height: 100%;\n}\n.booking-page .top-header {\n  position: sticky;\n  top: 0;\n  z-index: 10;\n  background: white;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 18px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.booking-page .top-header ion-icon {\n  font-size: 24px;\n  color: #3b82f6;\n}\n.booking-page .top-header h2 {\n  font-size: 18px;\n  font-weight: 600;\n  color: #111;\n}\n.booking-page .booking-tabs {\n  display: flex;\n  justify-content: space-around;\n  background: #fff;\n  padding: 10px 0;\n  border-radius: 12px;\n  margin: 12px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.booking-page .booking-tabs button {\n  flex: 1;\n  padding: 10px;\n  font-weight: 600;\n  color: #666;\n  border: none;\n  background: transparent;\n  transition: 0.3s;\n  border-radius: 8px;\n}\n.booking-page .booking-tabs button.active {\n  background:\n    linear-gradient(\n      45deg,\n      #2563eb,\n      #60a5fa);\n  color: white;\n  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);\n}\n.booking-page .tab-wrapper {\n  position: relative;\n  overflow: hidden;\n  min-height: 400px;\n}\n.booking-page .tab-pane {\n  position: absolute;\n  width: 100%;\n  transition: transform 0.4s ease, opacity 0.3s ease;\n}\n.booking-page .slide-in-left {\n  animation: slideInLeft 0.4s ease forwards;\n}\n.booking-page .slide-in-right {\n  animation: slideInRight 0.4s ease forwards;\n}\n@keyframes slideInLeft {\n  from {\n    transform: translateX(100%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(0);\n    opacity: 1;\n  }\n}\n@keyframes slideInRight {\n  from {\n    transform: translateX(-100%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(0);\n    opacity: 1;\n  }\n}\n.booking-page .booking-card {\n  background: white;\n  border-radius: 15px;\n  padding: 12px;\n  margin: 12px;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  transition: transform 0.3s ease;\n}\n.booking-page .booking-card:hover {\n  transform: scale(1.02);\n}\n.booking-page .booking-card .booking-info {\n  display: flex;\n  align-items: center;\n}\n.booking-page .booking-card .booking-info .service-icon {\n  font-size: 34px;\n  color: #2563eb;\n  margin-right: 12px;\n}\n.booking-page .booking-card .booking-info .details h4 {\n  font-size: 15px;\n  font-weight: 600;\n  color: #111;\n}\n.booking-page .booking-card .booking-info .details p {\n  font-size: 13px;\n  color: #666;\n  margin: 3px 0;\n}\n.booking-page .booking-card .booking-info .details .status {\n  font-size: 12px;\n  border-radius: 8px;\n  padding: 3px 8px;\n}\n.booking-page .booking-card .booking-info .details .status.Confirmed {\n  background: #e0f2fe;\n  color: #0284c7;\n}\n.booking-page .booking-card .booking-info .details .status.InProgress {\n  background: #fef9c3;\n  color: #ca8a04;\n}\n.booking-page .booking-card .booking-info .details .status.Completed {\n  background: #dcfce7;\n  color: #16a34a;\n}\n.booking-page .booking-card .booking-info .details .status.Cancelled {\n  background: #fee2e2;\n  color: #dc2626;\n}\n.booking-page .booking-card .booking-action {\n  text-align: right;\n}\n.booking-page .booking-card .booking-action .old-price {\n  text-decoration: line-through;\n  font-size: 12px;\n  color: #999;\n  display: block;\n}\n.booking-page .booking-card .booking-action .price {\n  font-weight: 700;\n  color: #111;\n  font-size: 14px;\n  display: block;\n}\n.booking-page .booking-card .booking-action ion-button {\n  margin-top: 4px;\n  font-size: 12px;\n  border-radius: 8px;\n}\n/*# sourceMappingURL=mybooking-details.css.map */\n"] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(MybookingDetails, { className: "MybookingDetails", filePath: "src/app/pages/user/mybooking-details/mybooking-details.ts", lineNumber: 14 });
})();
export {
  MybookingDetails
};
//# sourceMappingURL=mybooking-details-YIXZB2LJ.js.map
