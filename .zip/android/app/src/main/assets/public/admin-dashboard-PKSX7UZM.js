import {
  IonContent,
  IonIcon
} from "./chunk-OIW4YKS2.js";
import {
  CommonModule,
  FormsModule,
  NgClass,
  NgForOf
} from "./chunk-YNRRQX7A.js";
import {
  Component,
  Injectable,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassMap,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵproperty,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import {
  __spreadValues
} from "./chunk-EAE2VPRF.js";

// src/app/pages/admin/store/store.service.ts
var _StoreService = class _StoreService {
  constructor() {
    this.stores = [
      {
        id: "s1",
        name: "VPS KTC Nagar",
        location: "KTC Nagar",
        phone: "9999999999",
        openingHours: "9:00 AM - 8:00 PM",
        status: "Active",
        image: "assets/img/ktc-nagar.jpeg"
      },
      { id: "s2", name: "VPS Market", location: "Market Rd", status: "Active", image: "assets/img/market.jpeg" },
      { id: "s3", name: "VPS Vanarapettai", location: "Vanarapettai", status: "Inactive" }
    ];
  }
  getAll() {
    return [...this.stores];
  }
  getById(id) {
    return this.stores.find((s) => s.id === id);
  }
  add(store) {
    this.stores.unshift(store);
  }
  update(id, data) {
    const idx = this.stores.findIndex((s) => s.id === id);
    if (idx > -1)
      this.stores[idx] = __spreadValues(__spreadValues({}, this.stores[idx]), data);
  }
  delete(id) {
    this.stores = this.stores.filter((s) => s.id !== id);
  }
};
_StoreService.\u0275fac = function StoreService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _StoreService)();
};
_StoreService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _StoreService, factory: _StoreService.\u0275fac, providedIn: "root" });
var StoreService = _StoreService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

// src/app/pages/admin/admin-dashboard/admin-dashboard.ts
function AdminDashboard_div_44_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 21)(1, "div", 22);
    \u0275\u0275element(2, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 23)(4, "h4");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 24);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275property("ngClass", item_r1.type);
    \u0275\u0275advance();
    \u0275\u0275classMap(item_r1.icon);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(item_r1.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r1.description);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r1.time);
  }
}
var _AdminDashboard = class _AdminDashboard {
  constructor(storeSvc) {
    this.storeSvc = storeSvc;
    this.stats = { stores: 0, employees: 0, users: 0 };
    this.recentActivities = [
      {
        icon: "pi pi-cog",
        title: "Engine Oil Change Completed",
        description: "Customer Kavin completed oil change at VPS Motors.",
        time: "10 mins ago",
        type: "booking"
      },
      {
        icon: "pi pi-user-plus",
        title: "New Employee Added",
        description: "Arun joined VPS Tenkasi branch.",
        time: "2 hours ago",
        type: "employee"
      },
      {
        icon: "pi pi-home",
        title: "New Store Registered",
        description: "VPS Motors - Tirunelveli added successfully.",
        time: "1 day ago",
        type: "store"
      },
      {
        icon: "pi pi-exclamation-triangle",
        title: "Service Reminder Sent",
        description: "Oil Change Reminder sent to 25 users.",
        time: "3 days ago",
        type: "alert"
      }
    ];
    this.stats.stores = this.storeSvc.getAll().length;
    this.stats.employees = 12;
    this.stats.users = 238;
  }
};
_AdminDashboard.\u0275fac = function AdminDashboard_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AdminDashboard)(\u0275\u0275directiveInject(StoreService));
};
_AdminDashboard.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AdminDashboard, selectors: [["app-admin-dashboard"]], decls: 45, vars: 1, consts: [[1, "dashboard-page"], [1, "dashboard-header"], [1, "left"], ["src", "assets/img/admin-avatar.png", "alt", "Admin", 1, "avatar"], [1, "admin-info"], ["name", "notifications-outline", 1, "notif-icon"], [1, "stats-grid"], [1, "stat-card", "stores"], ["name", "storefront-outline"], [1, "details"], [1, "stat-card", "employees"], ["name", "people-outline"], [1, "stat-card", "users"], ["name", "person-circle-outline"], [1, "stat-card", "bookings"], ["name", "calendar-outline"], [1, "recent-activity-container"], [1, "section-title"], [1, "pi", "pi-history"], [1, "activity-list"], ["class", "activity-card", 4, "ngFor", "ngForOf"], [1, "activity-card"], [1, "icon-wrapper", 3, "ngClass"], [1, "activity-details"], [1, "time"]], template: function AdminDashboard_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1)(2, "div", 2);
    \u0275\u0275element(3, "img", 3);
    \u0275\u0275elementStart(4, "div", 4)(5, "h3");
    \u0275\u0275text(6, "Hi, Admin \u{1F44B}");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p");
    \u0275\u0275text(8, "Welcome back");
    \u0275\u0275elementEnd()()();
    \u0275\u0275element(9, "ion-icon", 5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 6)(11, "div", 7);
    \u0275\u0275element(12, "ion-icon", 8);
    \u0275\u0275elementStart(13, "div", 9)(14, "h4");
    \u0275\u0275text(15, "Stores");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "h2");
    \u0275\u0275text(17, "12");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(18, "div", 10);
    \u0275\u0275element(19, "ion-icon", 11);
    \u0275\u0275elementStart(20, "div", 9)(21, "h4");
    \u0275\u0275text(22, "Employees");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "h2");
    \u0275\u0275text(24, "35");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(25, "div", 12);
    \u0275\u0275element(26, "ion-icon", 13);
    \u0275\u0275elementStart(27, "div", 9)(28, "h4");
    \u0275\u0275text(29, "Users");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "h2");
    \u0275\u0275text(31, "210");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(32, "div", 14);
    \u0275\u0275element(33, "ion-icon", 15);
    \u0275\u0275elementStart(34, "div", 9)(35, "h4");
    \u0275\u0275text(36, "Bookings");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "h2");
    \u0275\u0275text(38, "58");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(39, "div", 16)(40, "h2", 17);
    \u0275\u0275element(41, "i", 18);
    \u0275\u0275text(42, " Recent Activities ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "div", 19);
    \u0275\u0275template(44, AdminDashboard_div_44_Template, 10, 6, "div", 20);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(44);
    \u0275\u0275property("ngForOf", ctx.recentActivities);
  }
}, dependencies: [IonContent, IonIcon, FormsModule, CommonModule, NgClass, NgForOf], styles: ['@charset "UTF-8";\n\n\n\n.dashboard-page[_ngcontent-%COMP%] {\n  --background: #f8f9ff;\n  padding: 16px;\n}\n.dashboard-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 20px;\n}\n.dashboard-header[_ngcontent-%COMP%]   .left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.dashboard-header[_ngcontent-%COMP%]   .left[_ngcontent-%COMP%]   .avatar[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n  border-radius: 50%;\n  object-fit: cover;\n  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n}\n.dashboard-header[_ngcontent-%COMP%]   .left[_ngcontent-%COMP%]   .admin-info[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 600;\n  margin: 0;\n}\n.dashboard-header[_ngcontent-%COMP%]   .left[_ngcontent-%COMP%]   .admin-info[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #666;\n  margin: 0;\n}\n.dashboard-header[_ngcontent-%COMP%]   .notif-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #2a2a72;\n}\n.stats-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 14px;\n  margin-bottom: 30px;\n}\n.stat-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  background: #fff;\n  border-radius: 16px;\n  padding: 16px;\n  box-shadow: 0 5px 14px rgba(0, 0, 0, 0.05);\n  animation: _ngcontent-%COMP%_fadeInUp 0.5s ease forwards;\n}\n.stat-card[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 30px;\n  color: #fff;\n  background:\n    linear-gradient(\n      135deg,\n      #2a2a72,\n      #009ffd);\n  padding: 10px;\n  border-radius: 14px;\n}\n.stat-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #444;\n  margin: 0;\n}\n.stat-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 700;\n  color: #2a2a72;\n  margin: 2px 0 0;\n}\n.stat-card.stores[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #00b09b,\n      #96c93d);\n}\n.stat-card.employees[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #f7971e,\n      #ffd200);\n}\n.stat-card.users[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #6a11cb,\n      #2575fc);\n}\n.stat-card.bookings[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #f54ea2,\n      #ff7676);\n}\n@keyframes _ngcontent-%COMP%_fadeInUp {\n  from {\n    opacity: 0;\n    transform: translateY(15px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n.recent-activity-container[_ngcontent-%COMP%] {\n  margin-top: 1rem;\n  background:\n    linear-gradient(\n      135deg,\n      #f8f9ff,\n      #eef1ff);\n  border-radius: 16px;\n  padding: 1.2rem;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);\n  animation: _ngcontent-%COMP%_fadeIn 0.8s ease-in;\n}\n.recent-activity-container[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%] {\n  font-size: 1.3rem;\n  font-weight: 600;\n  margin-bottom: 1rem;\n  color: #2a2a72;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 0.8rem;\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  background: #fff;\n  padding: 0.9rem;\n  border-radius: 12px;\n  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.05);\n  transition: transform 0.2s ease, box-shadow 0.2s ease;\n  animation: _ngcontent-%COMP%_slideUp 0.6s ease forwards;\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.1);\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]   .icon-wrapper[_ngcontent-%COMP%] {\n  width: 42px;\n  height: 42px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 50%;\n  font-size: 1.2rem;\n  color: #fff;\n  margin-right: 0.9rem;\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]   .icon-wrapper.booking[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #667eea,\n      #764ba2);\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]   .icon-wrapper.store[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #43cea2,\n      #185a9d);\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]   .icon-wrapper.employee[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #f7971e,\n      #ffd200);\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]   .icon-wrapper.alert[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #ff416c,\n      #ff4b2b);\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]   .activity-details[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 1rem;\n  color: #333;\n  font-weight: 600;\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]   .activity-details[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 4px 0;\n  font-size: 0.88rem;\n  color: #555;\n}\n.recent-activity-container[_ngcontent-%COMP%]   .activity-card[_ngcontent-%COMP%]   .activity-details[_ngcontent-%COMP%]   .time[_ngcontent-%COMP%] {\n  font-size: 0.75rem;\n  color: #888;\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes _ngcontent-%COMP%_slideUp {\n  from {\n    opacity: 0;\n    transform: translateY(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=admin-dashboard.css.map */'] });
var AdminDashboard = _AdminDashboard;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AdminDashboard, [{
    type: Component,
    args: [{ selector: "app-admin-dashboard", imports: [IonContent, IonIcon, FormsModule, CommonModule], template: '<ion-content class="dashboard-page">\r\n\r\n    <!-- \u{1F51D} Header -->\r\n    <div class="dashboard-header">\r\n        <div class="left">\r\n            <img src="assets/img/admin-avatar.png" alt="Admin" class="avatar" />\r\n            <div class="admin-info">\r\n                <h3>Hi, Admin \u{1F44B}</h3>\r\n                <p>Welcome back</p>\r\n            </div>\r\n        </div>\r\n        <ion-icon name="notifications-outline" class="notif-icon"></ion-icon>\r\n    </div>\r\n\r\n    <!-- \u{1F4CA} Stats Section -->\r\n    <div class="stats-grid">\r\n\r\n        <div class="stat-card stores">\r\n            <ion-icon name="storefront-outline"></ion-icon>\r\n            <div class="details">\r\n                <h4>Stores</h4>\r\n                <h2>12</h2>\r\n            </div>\r\n        </div>\r\n\r\n        <div class="stat-card employees">\r\n            <ion-icon name="people-outline"></ion-icon>\r\n            <div class="details">\r\n                <h4>Employees</h4>\r\n                <h2>35</h2>\r\n            </div>\r\n        </div>\r\n\r\n        <div class="stat-card users">\r\n            <ion-icon name="person-circle-outline"></ion-icon>\r\n            <div class="details">\r\n                <h4>Users</h4>\r\n                <h2>210</h2>\r\n            </div>\r\n        </div>\r\n\r\n        <div class="stat-card bookings">\r\n            <ion-icon name="calendar-outline"></ion-icon>\r\n            <div class="details">\r\n                <h4>Bookings</h4>\r\n                <h2>58</h2>\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n\r\n    <div class="recent-activity-container">\r\n        <h2 class="section-title">\r\n            <i class="pi pi-history"></i> Recent Activities\r\n        </h2>\r\n\r\n        <div class="activity-list">\r\n            <div class="activity-card" *ngFor="let item of recentActivities; let i = index">\r\n                <div class="icon-wrapper" [ngClass]="item.type">\r\n                    <i [class]="item.icon"></i>\r\n                </div>\r\n                <div class="activity-details">\r\n                    <h4>{{ item.title }}</h4>\r\n                    <p>{{ item.description }}</p>\r\n                    <span class="time">{{ item.time }}</span>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n\r\n</ion-content>', styles: ['@charset "UTF-8";\n\n/* src/app/pages/admin/admin-dashboard/admin-dashboard.scss */\n.dashboard-page {\n  --background: #f8f9ff;\n  padding: 16px;\n}\n.dashboard-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 20px;\n}\n.dashboard-header .left {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.dashboard-header .left .avatar {\n  width: 48px;\n  height: 48px;\n  border-radius: 50%;\n  object-fit: cover;\n  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n}\n.dashboard-header .left .admin-info h3 {\n  font-size: 16px;\n  font-weight: 600;\n  margin: 0;\n}\n.dashboard-header .left .admin-info p {\n  font-size: 13px;\n  color: #666;\n  margin: 0;\n}\n.dashboard-header .notif-icon {\n  font-size: 24px;\n  color: #2a2a72;\n}\n.stats-grid {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 14px;\n  margin-bottom: 30px;\n}\n.stat-card {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  background: #fff;\n  border-radius: 16px;\n  padding: 16px;\n  box-shadow: 0 5px 14px rgba(0, 0, 0, 0.05);\n  animation: fadeInUp 0.5s ease forwards;\n}\n.stat-card ion-icon {\n  font-size: 30px;\n  color: #fff;\n  background:\n    linear-gradient(\n      135deg,\n      #2a2a72,\n      #009ffd);\n  padding: 10px;\n  border-radius: 14px;\n}\n.stat-card .details h4 {\n  font-size: 14px;\n  color: #444;\n  margin: 0;\n}\n.stat-card .details h2 {\n  font-size: 18px;\n  font-weight: 700;\n  color: #2a2a72;\n  margin: 2px 0 0;\n}\n.stat-card.stores ion-icon {\n  background:\n    linear-gradient(\n      135deg,\n      #00b09b,\n      #96c93d);\n}\n.stat-card.employees ion-icon {\n  background:\n    linear-gradient(\n      135deg,\n      #f7971e,\n      #ffd200);\n}\n.stat-card.users ion-icon {\n  background:\n    linear-gradient(\n      135deg,\n      #6a11cb,\n      #2575fc);\n}\n.stat-card.bookings ion-icon {\n  background:\n    linear-gradient(\n      135deg,\n      #f54ea2,\n      #ff7676);\n}\n@keyframes fadeInUp {\n  from {\n    opacity: 0;\n    transform: translateY(15px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n.recent-activity-container {\n  margin-top: 1rem;\n  background:\n    linear-gradient(\n      135deg,\n      #f8f9ff,\n      #eef1ff);\n  border-radius: 16px;\n  padding: 1.2rem;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);\n  animation: fadeIn 0.8s ease-in;\n}\n.recent-activity-container .section-title {\n  font-size: 1.3rem;\n  font-weight: 600;\n  margin-bottom: 1rem;\n  color: #2a2a72;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.recent-activity-container .activity-list {\n  display: flex;\n  flex-direction: column;\n  gap: 0.8rem;\n}\n.recent-activity-container .activity-card {\n  display: flex;\n  align-items: flex-start;\n  background: #fff;\n  padding: 0.9rem;\n  border-radius: 12px;\n  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.05);\n  transition: transform 0.2s ease, box-shadow 0.2s ease;\n  animation: slideUp 0.6s ease forwards;\n}\n.recent-activity-container .activity-card:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.1);\n}\n.recent-activity-container .activity-card .icon-wrapper {\n  width: 42px;\n  height: 42px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 50%;\n  font-size: 1.2rem;\n  color: #fff;\n  margin-right: 0.9rem;\n}\n.recent-activity-container .activity-card .icon-wrapper.booking {\n  background:\n    linear-gradient(\n      135deg,\n      #667eea,\n      #764ba2);\n}\n.recent-activity-container .activity-card .icon-wrapper.store {\n  background:\n    linear-gradient(\n      135deg,\n      #43cea2,\n      #185a9d);\n}\n.recent-activity-container .activity-card .icon-wrapper.employee {\n  background:\n    linear-gradient(\n      135deg,\n      #f7971e,\n      #ffd200);\n}\n.recent-activity-container .activity-card .icon-wrapper.alert {\n  background:\n    linear-gradient(\n      135deg,\n      #ff416c,\n      #ff4b2b);\n}\n.recent-activity-container .activity-card .activity-details h4 {\n  margin: 0;\n  font-size: 1rem;\n  color: #333;\n  font-weight: 600;\n}\n.recent-activity-container .activity-card .activity-details p {\n  margin: 4px 0;\n  font-size: 0.88rem;\n  color: #555;\n}\n.recent-activity-container .activity-card .activity-details .time {\n  font-size: 0.75rem;\n  color: #888;\n}\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes slideUp {\n  from {\n    opacity: 0;\n    transform: translateY(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=admin-dashboard.css.map */\n'] }]
  }], () => [{ type: StoreService }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AdminDashboard, { className: "AdminDashboard", filePath: "src/app/pages/admin/admin-dashboard/admin-dashboard.ts", lineNumber: 13 });
})();
export {
  AdminDashboard
};
//# sourceMappingURL=admin-dashboard-PKSX7UZM.js.map
