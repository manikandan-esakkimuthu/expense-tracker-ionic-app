import {
  IonButton,
  IonCard,
  IonContent,
  IonIcon
} from "./chunk-OIW4YKS2.js";
import {
  CommonModule,
  FormsModule,
  NgClass,
  NgForOf
} from "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵproperty,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/employee/bookings/bookings.ts
function Bookings_ion_card_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 7)(1, "div", 8);
    \u0275\u0275element(2, "ion-icon", 9);
    \u0275\u0275elementStart(3, "div", 10)(4, "h4");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 11);
    \u0275\u0275element(9, "ion-icon", 12);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 13);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(13, "div", 14)(14, "p", 15);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "ion-button", 16);
    \u0275\u0275text(17, "Start");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const booking_r1 = ctx.$implicit;
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(booking_r1.service);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(booking_r1.customer);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", booking_r1.time, " ");
    \u0275\u0275advance();
    \u0275\u0275property("ngClass", booking_r1.status);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(booking_r1.status);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(booking_r1.price);
  }
}
var _Bookings = class _Bookings {
  constructor() {
    this.activeTab = "today";
    this.bookings = [
      {
        customer: "Arun Kumar",
        service: "Engine Oil Change",
        time: "10:30 AM",
        price: "\u20B9800",
        status: "Confirmed"
      },
      {
        customer: "Priya Motors",
        service: "Full Service",
        time: "1:00 PM",
        price: "\u20B92,000",
        status: "In Progress"
      },
      {
        customer: "Siva Raj",
        service: "Tyre Replacement",
        time: "4:15 PM",
        price: "\u20B91,200",
        status: "Completed"
      }
    ];
  }
  changeTab(tab) {
    this.activeTab = tab;
  }
};
_Bookings.\u0275fac = function Bookings_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _Bookings)();
};
_Bookings.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Bookings, selectors: [["app-bookings"]], decls: 14, vars: 7, consts: [[1, "bookings-page"], [1, "top-header", "fade-in"], ["name", "notifications-outline"], [1, "booking-tabs"], [3, "click"], [1, "bookings-list"], ["class", "booking-card slide-up", 4, "ngFor", "ngForOf"], [1, "booking-card", "slide-up"], [1, "left-info"], ["name", "construct-outline", 1, "service-icon"], [1, "details"], [1, "time"], ["name", "time-outline"], [1, "status", 3, "ngClass"], [1, "right-info"], [1, "price"], ["fill", "solid", "color", "primary", "size", "small", 1, "action-btn"]], template: function Bookings_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1)(2, "h2");
    \u0275\u0275text(3, "My Bookings");
    \u0275\u0275elementEnd();
    \u0275\u0275element(4, "ion-icon", 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 3)(6, "button", 4);
    \u0275\u0275listener("click", function Bookings_Template_button_click_6_listener() {
      return ctx.changeTab("today");
    });
    \u0275\u0275text(7, "Today");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "button", 4);
    \u0275\u0275listener("click", function Bookings_Template_button_click_8_listener() {
      return ctx.changeTab("upcoming");
    });
    \u0275\u0275text(9, "Upcoming");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "button", 4);
    \u0275\u0275listener("click", function Bookings_Template_button_click_10_listener() {
      return ctx.changeTab("completed");
    });
    \u0275\u0275text(11, "Completed");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "div", 5);
    \u0275\u0275template(13, Bookings_ion_card_13_Template, 18, 6, "ion-card", 6);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275classProp("active", ctx.activeTab === "today");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.activeTab === "upcoming");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.activeTab === "completed");
    \u0275\u0275advance(3);
    \u0275\u0275property("ngForOf", ctx.bookings);
  }
}, dependencies: [IonCard, IonIcon, IonButton, FormsModule, CommonModule, NgClass, NgForOf, IonContent], styles: ["\n\n.bookings-page[_ngcontent-%COMP%] {\n  background: #f9fafb;\n  min-height: 100%;\n}\n.bookings-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%] {\n  background: #ffffff;\n  padding: 12px 18px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);\n  position: sticky;\n  top: 0;\n  z-index: 10;\n}\n.bookings-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 700;\n  color: #1e3a8a;\n}\n.bookings-page[_ngcontent-%COMP%]   .top-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n  color: #2563eb;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-around;\n  background: #ffffff;\n  padding: 10px;\n  border-radius: 12px;\n  margin: 12px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  flex: 1;\n  background: transparent;\n  border: none;\n  font-weight: 600;\n  padding: 8px;\n  border-radius: 8px;\n  color: #6b7280;\n  transition: all 0.3s ease;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-tabs[_ngcontent-%COMP%]   button.active[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      45deg,\n      #2563eb,\n      #60a5fa);\n  color: #fff;\n  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);\n}\n.bookings-page[_ngcontent-%COMP%]   .bookings-list[_ngcontent-%COMP%] {\n  padding: 0 12px;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 15px;\n  margin-bottom: 14px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);\n  transition: transform 0.3s ease;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]:hover {\n  transform: scale(1.02);\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%]   .service-icon[_ngcontent-%COMP%] {\n  font-size: 30px;\n  color: #2563eb;\n  margin-right: 10px;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 700;\n  color: #111827;\n  margin: 0;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 3px 0;\n  font-size: 13px;\n  color: #6b7280;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .time[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  margin-right: 4px;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 3px 8px;\n  font-size: 12px;\n  border-radius: 8px;\n  font-weight: 600;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.Confirmed[_ngcontent-%COMP%] {\n  background: #dbeafe;\n  color: #2563eb;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.In\\ Progress[_ngcontent-%COMP%] {\n  background: #fef9c3;\n  color: #ca8a04;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .left-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .status.Completed[_ngcontent-%COMP%] {\n  background: #dcfce7;\n  color: #16a34a;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .right-info[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .right-info[_ngcontent-%COMP%]   .price[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #111827;\n  margin-bottom: 6px;\n}\n.bookings-page[_ngcontent-%COMP%]   .booking-card[_ngcontent-%COMP%]   .right-info[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%] {\n  border-radius: 10px;\n  --background:\n    linear-gradient(\n      45deg,\n      #2563eb,\n      #60a5fa);\n}\n.fade-in[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_fadeIn 0.6s ease both;\n}\n.slide-up[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_slideUp 0.6s ease both;\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes _ngcontent-%COMP%_slideUp {\n  from {\n    opacity: 0;\n    transform: translateY(30px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=bookings.css.map */"] });
var Bookings = _Bookings;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Bookings, [{
    type: Component,
    args: [{ selector: "app-bookings", imports: [IonCard, IonIcon, IonButton, FormsModule, CommonModule, IonContent], template: `<ion-content class="bookings-page">\r
    <!-- Top Header -->\r
    <div class="top-header fade-in">\r
        <h2>My Bookings</h2>\r
        <ion-icon name="notifications-outline"></ion-icon>\r
    </div>\r
\r
    <!-- Tabs -->\r
    <div class="booking-tabs">\r
        <button [class.active]="activeTab === 'today'" (click)="changeTab('today')">Today</button>\r
        <button [class.active]="activeTab === 'upcoming'" (click)="changeTab('upcoming')">Upcoming</button>\r
        <button [class.active]="activeTab === 'completed'" (click)="changeTab('completed')">Completed</button>\r
    </div>\r
\r
    <!-- Booking Cards -->\r
    <div class="bookings-list">\r
        <ion-card *ngFor="let booking of bookings" class="booking-card slide-up">\r
            <div class="left-info">\r
                <ion-icon name="construct-outline" class="service-icon"></ion-icon>\r
                <div class="details">\r
                    <h4>{{ booking.service }}</h4>\r
                    <p>{{ booking.customer }}</p>\r
                    <p class="time">\r
                        <ion-icon name="time-outline"></ion-icon> {{ booking.time }}\r
                    </p>\r
                    <span class="status" [ngClass]="booking.status">{{ booking.status }}</span>\r
                </div>\r
            </div>\r
\r
            <div class="right-info">\r
                <p class="price">{{ booking.price }}</p>\r
                <ion-button fill="solid" color="primary" size="small" class="action-btn">Start</ion-button>\r
            </div>\r
        </ion-card>\r
    </div>\r
</ion-content>`, styles: ["/* src/app/pages/employee/bookings/bookings.scss */\n.bookings-page {\n  background: #f9fafb;\n  min-height: 100%;\n}\n.bookings-page .top-header {\n  background: #ffffff;\n  padding: 12px 18px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);\n  position: sticky;\n  top: 0;\n  z-index: 10;\n}\n.bookings-page .top-header h2 {\n  font-size: 18px;\n  font-weight: 700;\n  color: #1e3a8a;\n}\n.bookings-page .top-header ion-icon {\n  font-size: 22px;\n  color: #2563eb;\n}\n.bookings-page .booking-tabs {\n  display: flex;\n  justify-content: space-around;\n  background: #ffffff;\n  padding: 10px;\n  border-radius: 12px;\n  margin: 12px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.bookings-page .booking-tabs button {\n  flex: 1;\n  background: transparent;\n  border: none;\n  font-weight: 600;\n  padding: 8px;\n  border-radius: 8px;\n  color: #6b7280;\n  transition: all 0.3s ease;\n}\n.bookings-page .booking-tabs button.active {\n  background:\n    linear-gradient(\n      45deg,\n      #2563eb,\n      #60a5fa);\n  color: #fff;\n  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);\n}\n.bookings-page .bookings-list {\n  padding: 0 12px;\n}\n.bookings-page .booking-card {\n  background: #ffffff;\n  border-radius: 15px;\n  margin-bottom: 14px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);\n  transition: transform 0.3s ease;\n}\n.bookings-page .booking-card:hover {\n  transform: scale(1.02);\n}\n.bookings-page .booking-card .left-info {\n  display: flex;\n  align-items: flex-start;\n}\n.bookings-page .booking-card .left-info .service-icon {\n  font-size: 30px;\n  color: #2563eb;\n  margin-right: 10px;\n}\n.bookings-page .booking-card .left-info .details h4 {\n  font-size: 15px;\n  font-weight: 700;\n  color: #111827;\n  margin: 0;\n}\n.bookings-page .booking-card .left-info .details p {\n  margin: 3px 0;\n  font-size: 13px;\n  color: #6b7280;\n}\n.bookings-page .booking-card .left-info .details .time ion-icon {\n  font-size: 14px;\n  margin-right: 4px;\n}\n.bookings-page .booking-card .left-info .details .status {\n  display: inline-block;\n  padding: 3px 8px;\n  font-size: 12px;\n  border-radius: 8px;\n  font-weight: 600;\n}\n.bookings-page .booking-card .left-info .details .status.Confirmed {\n  background: #dbeafe;\n  color: #2563eb;\n}\n.bookings-page .booking-card .left-info .details .status.In\\ Progress {\n  background: #fef9c3;\n  color: #ca8a04;\n}\n.bookings-page .booking-card .left-info .details .status.Completed {\n  background: #dcfce7;\n  color: #16a34a;\n}\n.bookings-page .booking-card .right-info {\n  text-align: right;\n}\n.bookings-page .booking-card .right-info .price {\n  font-size: 14px;\n  font-weight: 700;\n  color: #111827;\n  margin-bottom: 6px;\n}\n.bookings-page .booking-card .right-info .action-btn {\n  border-radius: 10px;\n  --background:\n    linear-gradient(\n      45deg,\n      #2563eb,\n      #60a5fa);\n}\n.fade-in {\n  animation: fadeIn 0.6s ease both;\n}\n.slide-up {\n  animation: slideUp 0.6s ease both;\n}\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes slideUp {\n  from {\n    opacity: 0;\n    transform: translateY(30px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=bookings.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Bookings, { className: "Bookings", filePath: "src/app/pages/employee/bookings/bookings.ts", lineNumber: 12 });
})();
export {
  Bookings
};
//# sourceMappingURL=bookings-QHEFYTC5.js.map
