import {
  AlertController
} from "./chunk-PBX6UFXU.js";
import {
  clipboardOutline,
  logOutOutline,
  notificationsOutline,
  personCircleOutline,
  speedometerOutline
} from "./chunk-TD74DZFV.js";
import {
  IonIcon,
  IonLabel,
  IonTabBar,
  IonTabButton,
  IonTabs
} from "./chunk-OIW4YKS2.js";
import {
  Router
} from "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵtext
} from "./chunk-NPNYO6CD.js";
import "./chunk-4625MWOI.js";
import "./chunk-W7NNY2EY.js";
import "./chunk-LT3LEW4O.js";
import "./chunk-TH3NAJYP.js";
import "./chunk-XOTLEQNJ.js";
import "./chunk-UMTFGNU2.js";
import "./chunk-RCMGGQIF.js";
import "./chunk-6YCZ7XWX.js";
import "./chunk-YZJQZ23Y.js";
import "./chunk-6TWGLSWA.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-CXDFQPX7.js";
import "./chunk-DFAOHKQG.js";
import "./chunk-F3JJ4YWB.js";
import "./chunk-QOQL43QQ.js";
import "./chunk-5YIQV2FO.js";
import "./chunk-IVBL4Y7V.js";
import "./chunk-NNTRQ7Y2.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import {
  __async
} from "./chunk-EAE2VPRF.js";

// src/app/pages/employee-tabs/employee-tabs.ts
var _EmployeeTabs = class _EmployeeTabs {
  constructor(router, alertCtrl) {
    this.router = router;
    this.alertCtrl = alertCtrl;
    addIcons({ speedometerOutline, clipboardOutline, notificationsOutline, personCircleOutline, logOutOutline });
  }
  logout() {
    return __async(this, null, function* () {
      const alert = yield this.alertCtrl.create({
        header: "Logout",
        message: "Are you sure you want to log out?",
        buttons: [
          {
            text: "Cancel",
            role: "cancel"
          },
          {
            text: "Yes, Logout",
            handler: () => {
              localStorage.clear();
              this.router.navigateByUrl("/login", { replaceUrl: true });
            }
          }
        ]
      });
      yield alert.present();
    });
  }
};
_EmployeeTabs.\u0275fac = function EmployeeTabs_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EmployeeTabs)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(AlertController));
};
_EmployeeTabs.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _EmployeeTabs, selectors: [["app-employee-tabs"]], decls: 22, vars: 0, consts: [["slot", "bottom"], ["tab", "employee-dashboard"], ["name", "speedometer-outline"], ["tab", "bookings"], ["name", "clipboard-outline"], ["tab", "employee-notification"], ["name", "notifications-outline"], ["tab", "employee-profile"], ["name", "person-circle-outline"], [3, "click"], ["name", "log-out-outline", 1, "logout-icon"]], template: function EmployeeTabs_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-tabs")(1, "ion-tab-bar", 0)(2, "ion-tab-button", 1);
    \u0275\u0275element(3, "ion-icon", 2);
    \u0275\u0275elementStart(4, "ion-label");
    \u0275\u0275text(5, "Dashboard");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "ion-tab-button", 3);
    \u0275\u0275element(7, "ion-icon", 4);
    \u0275\u0275elementStart(8, "ion-label");
    \u0275\u0275text(9, "Bookings");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "ion-tab-button", 5);
    \u0275\u0275element(11, "ion-icon", 6);
    \u0275\u0275elementStart(12, "ion-label");
    \u0275\u0275text(13, "Alerts");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "ion-tab-button", 7);
    \u0275\u0275element(15, "ion-icon", 8);
    \u0275\u0275elementStart(16, "ion-label");
    \u0275\u0275text(17, "Profile");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "ion-tab-button", 9);
    \u0275\u0275listener("click", function EmployeeTabs_Template_ion_tab_button_click_18_listener() {
      return ctx.logout();
    });
    \u0275\u0275element(19, "ion-icon", 10);
    \u0275\u0275elementStart(20, "ion-label");
    \u0275\u0275text(21, "Logout");
    \u0275\u0275elementEnd()()()();
  }
}, dependencies: [IonTabBar, IonTabs, IonIcon, IonTabButton, IonLabel], encapsulation: 2 });
var EmployeeTabs = _EmployeeTabs;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EmployeeTabs, [{
    type: Component,
    args: [{ selector: "app-employee-tabs", imports: [IonTabBar, IonTabs, IonIcon, IonTabButton, IonLabel], template: '<ion-tabs>\r\n    <ion-tab-bar slot="bottom">\r\n        <ion-tab-button tab="employee-dashboard">\r\n            <ion-icon name="speedometer-outline"></ion-icon>\r\n            <ion-label>Dashboard</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="bookings">\r\n            <ion-icon name="clipboard-outline"></ion-icon>\r\n            <ion-label>Bookings</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="employee-notification">\r\n            <ion-icon name="notifications-outline"></ion-icon>\r\n            <ion-label>Alerts</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="employee-profile">\r\n            <ion-icon name="person-circle-outline"></ion-icon>\r\n            <ion-label>Profile</ion-label>\r\n        </ion-tab-button>\r\n        <ion-tab-button (click)="logout()">\r\n            <ion-icon name="log-out-outline" class="logout-icon"></ion-icon>\r\n            <ion-label>Logout</ion-label>\r\n        </ion-tab-button>\r\n    </ion-tab-bar>\r\n</ion-tabs>' }]
  }], () => [{ type: Router }, { type: AlertController }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(EmployeeTabs, { className: "EmployeeTabs", filePath: "src/app/pages/employee-tabs/employee-tabs.ts", lineNumber: 13 });
})();

// src/app/pages/employee/employee.routes.ts
var EMPLOYEE_ROUTES = [
  {
    path: "",
    component: EmployeeTabs,
    children: [
      // 🧭 Employee Dashboard — Default first page
      {
        path: "employee-dashboard",
        loadComponent: () => import("./employee-dashboard-G5CODIVF.js").then((m) => m.EmployeeDashboard)
      },
      {
        path: "bookings",
        loadComponent: () => import("./bookings-QHEFYTC5.js").then((m) => m.Bookings)
      },
      {
        path: "employee-notification",
        loadComponent: () => import("./employee-notification-XTA6PZSV.js").then((m) => m.EmployeeNotification)
      },
      {
        path: "employee-profile",
        loadComponent: () => import("./employee-profile-G34ZBEGN.js").then((m) => m.EmployeeProfile)
      },
      // 👉 Redirect to dashboard by default
      {
        path: "",
        redirectTo: "employee-dashboard",
        pathMatch: "full"
      }
    ]
  }
];
export {
  EMPLOYEE_ROUTES
};
//# sourceMappingURL=employee.routes-LUKOJH5V.js.map
