import {
  IonIcon,
  IonLabel,
  IonTabBar,
  IonTabButton,
  IonTabs,
  IonicModule
} from "./chunk-PBX6UFXU.js";
import {
  homeOutline,
  peopleOutline,
  personCircleOutline,
  settingsOutline,
  storefrontOutline
} from "./chunk-TD74DZFV.js";
import "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵtext
} from "./chunk-NPNYO6CD.js";
import "./chunk-4625MWOI.js";
import "./chunk-W7NNY2EY.js";
import "./chunk-LT3LEW4O.js";
import "./chunk-TH3NAJYP.js";
import "./chunk-XOTLEQNJ.js";
import "./chunk-UMTFGNU2.js";
import "./chunk-RCMGGQIF.js";
import "./chunk-6YCZ7XWX.js";
import "./chunk-YZJQZ23Y.js";
import "./chunk-6TWGLSWA.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-CXDFQPX7.js";
import "./chunk-DFAOHKQG.js";
import "./chunk-F3JJ4YWB.js";
import "./chunk-QOQL43QQ.js";
import "./chunk-5YIQV2FO.js";
import "./chunk-IVBL4Y7V.js";
import "./chunk-NNTRQ7Y2.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/expense/users/users-tabs/users-tabs.ts
var _UsersTabs = class _UsersTabs {
  constructor() {
    addIcons({ homeOutline, storefrontOutline, peopleOutline, personCircleOutline, settingsOutline });
  }
};
_UsersTabs.\u0275fac = function UsersTabs_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _UsersTabs)();
};
_UsersTabs.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _UsersTabs, selectors: [["app-users-tabs"]], decls: 22, vars: 0, consts: [["slot", "bottom", 1, "admin-tab-bar"], ["tab", "user-dashboard"], ["name", "home-outline"], ["tab", "expenses"], ["name", "storefront-outline"], ["tab", "reports"], ["name", "people-outline"], ["tab", "profile"], ["name", "person-circle-outline"], ["tab", "settings"], ["name", "settings-outline"]], template: function UsersTabs_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-tabs")(1, "ion-tab-bar", 0)(2, "ion-tab-button", 1);
    \u0275\u0275element(3, "ion-icon", 2);
    \u0275\u0275elementStart(4, "ion-label");
    \u0275\u0275text(5, "Dashboard");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "ion-tab-button", 3);
    \u0275\u0275element(7, "ion-icon", 4);
    \u0275\u0275elementStart(8, "ion-label");
    \u0275\u0275text(9, "Expenses");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "ion-tab-button", 5);
    \u0275\u0275element(11, "ion-icon", 6);
    \u0275\u0275elementStart(12, "ion-label");
    \u0275\u0275text(13, "Reports");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "ion-tab-button", 7);
    \u0275\u0275element(15, "ion-icon", 8);
    \u0275\u0275elementStart(16, "ion-label");
    \u0275\u0275text(17, "Profile");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "ion-tab-button", 9);
    \u0275\u0275element(19, "ion-icon", 10);
    \u0275\u0275elementStart(20, "ion-label");
    \u0275\u0275text(21, "Settings");
    \u0275\u0275elementEnd()()()();
  }
}, dependencies: [IonicModule, IonIcon, IonLabel, IonTabBar, IonTabButton, IonTabs], encapsulation: 2 });
var UsersTabs = _UsersTabs;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UsersTabs, [{
    type: Component,
    args: [{ selector: "app-users-tabs", imports: [IonicModule], template: '<ion-tabs>\r\n    <ion-tab-bar slot="bottom" class="admin-tab-bar">\r\n        <ion-tab-button tab="user-dashboard">\r\n            <ion-icon name="home-outline"></ion-icon>\r\n            <ion-label>Dashboard</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="expenses">\r\n            <ion-icon name="storefront-outline"></ion-icon>\r\n            <ion-label>Expenses</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="reports">\r\n            <ion-icon name="people-outline"></ion-icon>\r\n            <ion-label>Reports</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="profile">\r\n            <ion-icon name="person-circle-outline"></ion-icon>\r\n            <ion-label>Profile</ion-label>\r\n        </ion-tab-button>\r\n\r\n        <ion-tab-button tab="settings">\r\n            <ion-icon name="settings-outline"></ion-icon>\r\n            <ion-label>Settings</ion-label>\r\n        </ion-tab-button>\r\n    </ion-tab-bar>\r\n</ion-tabs>' }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(UsersTabs, { className: "UsersTabs", filePath: "src/app/pages/expense/users/users-tabs/users-tabs.ts", lineNumber: 12 });
})();

// src/app/pages/expense/expense.routes.ts
var EXPENSE_ROUTES = [
  {
    path: "",
    component: UsersTabs,
    children: [
      {
        path: "user-dashboard",
        loadComponent: () => import("./user-dashboard-V4U7BSMJ.js").then((m) => m.UserDashboard)
      },
      {
        path: "expenses",
        loadComponent: () => import("./expenses-EHKWKPA3.js").then((m) => m.Expenses)
      },
      {
        path: "reports",
        loadComponent: () => import("./reports-6ZTQGMPO.js").then((m) => m.Reports)
      },
      {
        path: "profile",
        loadComponent: () => import("./profile-YUL3GPML.js").then((m) => m.Profile)
      },
      {
        path: "add-expense",
        loadComponent: () => import("./add-expense-RI576TIB.js").then((m) => m.AddExpense)
      },
      {
        path: "",
        redirectTo: "user-dashboard",
        pathMatch: "full"
      }
    ]
  }
];
export {
  EXPENSE_ROUTES
};
//# sourceMappingURL=expense.routes-3EODBZMZ.js.map
