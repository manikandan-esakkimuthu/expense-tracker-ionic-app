import {
  WebPlugin
} from "./chunk-H2NKNW5T.js";
import {
  __async
} from "./chunk-EAE2VPRF.js";

// node_modules/@capacitor/splash-screen/dist/esm/web.js
var SplashScreenWeb = class extends WebPlugin {
  show(_options) {
    return __async(this, null, function* () {
      return void 0;
    });
  }
  hide(_options) {
    return __async(this, null, function* () {
      return void 0;
    });
  }
};
export {
  SplashScreenWeb
};
//# sourceMappingURL=web-G6AUPPXT.js.map
