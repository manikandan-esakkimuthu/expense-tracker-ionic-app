import {
  alertCircleOutline,
  arrowBackOutline,
  arrowUndoCircleSharp,
  checkmarkDoneCircleOutline,
  giftOutline,
  notificationsOutline,
  settingsOutline
} from "./chunk-TD74DZFV.js";
import {
  IonContent,
  IonIcon
} from "./chunk-OIW4YKS2.js";
import "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵtext
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import "./chunk-EAE2VPRF.js";

// src/app/pages/user/user-notification/user-notification.ts
var _UserNotification = class _UserNotification {
  constructor() {
    addIcons({ giftOutline, arrowUndoCircleSharp, notificationsOutline, settingsOutline, checkmarkDoneCircleOutline, alertCircleOutline, arrowBackOutline });
  }
};
_UserNotification.\u0275fac = function UserNotification_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _UserNotification)();
};
_UserNotification.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _UserNotification, selectors: [["app-user-notification"]], decls: 43, vars: 0, consts: [[1, "notif-page"], [1, "notif-header"], ["name", "arrow-undo-circle-sharp", 1, "back-icon"], ["name", "settings-outline", 1, "settings-icon"], [1, "notif-list"], [1, "notif-card", "reminder"], ["name", "alert-circle-outline", 1, "notif-icon"], [1, "notif-details"], [1, "notif-meta"], [1, "badge", "reminder-badge"], [1, "time"], [1, "notif-card", "completed"], ["name", "checkmark-done-circle-outline", 1, "notif-icon"], [1, "badge", "completed-badge"], [1, "notif-card", "offer"], ["name", "gift-outline", 1, "notif-icon"], [1, "badge", "offer-badge"]], template: function UserNotification_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1);
    \u0275\u0275element(2, "ion-icon", 2);
    \u0275\u0275elementStart(3, "h2");
    \u0275\u0275text(4, "Notifications");
    \u0275\u0275elementEnd();
    \u0275\u0275element(5, "ion-icon", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 4)(7, "div", 5);
    \u0275\u0275element(8, "ion-icon", 6);
    \u0275\u0275elementStart(9, "div", 7)(10, "h3");
    \u0275\u0275text(11, "Oil Change Reminder");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "p");
    \u0275\u0275text(13, "Your last oil change was 3 months ago. It\u2019s time for a new one!");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "div", 8)(15, "span", 9);
    \u0275\u0275text(16, "Reminder");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span", 10);
    \u0275\u0275text(18, "2h ago");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(19, "div", 11);
    \u0275\u0275element(20, "ion-icon", 12);
    \u0275\u0275elementStart(21, "div", 7)(22, "h3");
    \u0275\u0275text(23, "Bike Wash Completed");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "p");
    \u0275\u0275text(25, "Your booking for Bike Wash has been completed successfully.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 8)(27, "span", 13);
    \u0275\u0275text(28, "Completed");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "span", 10);
    \u0275\u0275text(30, "Yesterday");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(31, "div", 14);
    \u0275\u0275element(32, "ion-icon", 15);
    \u0275\u0275elementStart(33, "div", 7)(34, "h3");
    \u0275\u0275text(35, "Special Discount!");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "p");
    \u0275\u0275text(37, "Get 20% off on your next service booking this week.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "div", 8)(39, "span", 16);
    \u0275\u0275text(40, "Offer");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "span", 10);
    \u0275\u0275text(42, "1 day ago");
    \u0275\u0275elementEnd()()()()()();
  }
}, dependencies: [IonIcon, IonContent], styles: ["\n\n.notif-page[_ngcontent-%COMP%] {\n  --background:\n    linear-gradient(\n      180deg,\n      #f5f7fa,\n      #fff);\n  padding: 12px;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 12px;\n  position: sticky;\n  top: 0;\n  background: white;\n  z-index: 10;\n  padding: 10px;\n  border-radius: 10px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);\n}\n.notif-page[_ngcontent-%COMP%]   .notif-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #007aff;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  animation: _ngcontent-%COMP%_fadeIn 0.6s ease;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  padding: 14px;\n  background: #fff;\n  border-radius: 16px;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);\n  transition: transform 0.2s ease, box-shadow 0.2s ease;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card[_ngcontent-%COMP%]:hover {\n  transform: scale(1.02);\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card[_ngcontent-%COMP%]   .notif-icon[_ngcontent-%COMP%] {\n  font-size: 28px;\n  align-self: center;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card[_ngcontent-%COMP%]   .notif-details[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 600;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card[_ngcontent-%COMP%]   .notif-details[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #555;\n  margin: 4px 0;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card[_ngcontent-%COMP%]   .notif-details[_ngcontent-%COMP%]   .notif-meta[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 12px;\n  margin-top: 4px;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card[_ngcontent-%COMP%]   .notif-details[_ngcontent-%COMP%]   .notif-meta[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%] {\n  padding: 4px 8px;\n  border-radius: 10px;\n  font-weight: 500;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card.reminder[_ngcontent-%COMP%]   .notif-icon[_ngcontent-%COMP%] {\n  color: #ff9f43;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card.reminder[_ngcontent-%COMP%]   .reminder-badge[_ngcontent-%COMP%] {\n  background: #ffe8c2;\n  color: #b65c00;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card.completed[_ngcontent-%COMP%]   .notif-icon[_ngcontent-%COMP%] {\n  color: #2ecc71;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card.completed[_ngcontent-%COMP%]   .completed-badge[_ngcontent-%COMP%] {\n  background: #d3f9d8;\n  color: #116530;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card.offer[_ngcontent-%COMP%]   .notif-icon[_ngcontent-%COMP%] {\n  color: #e84393;\n}\n.notif-page[_ngcontent-%COMP%]   .notif-card.offer[_ngcontent-%COMP%]   .offer-badge[_ngcontent-%COMP%] {\n  background: #ffd6e8;\n  color: #9b0955;\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=user-notification.css.map */"] });
var UserNotification = _UserNotification;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserNotification, [{
    type: Component,
    args: [{ selector: "app-user-notification", imports: [IonIcon, IonContent], template: '<ion-content class="notif-page">\r\n\r\n    <!-- \u{1F51D} Header -->\r\n    <div class="notif-header">\r\n        <ion-icon name="arrow-undo-circle-sharp" class="back-icon"></ion-icon>\r\n        <h2>Notifications</h2>\r\n        <ion-icon name="settings-outline" class="settings-icon"></ion-icon>\r\n    </div>\r\n\r\n    <!-- \u{1F514} Notification List -->\r\n    <div class="notif-list">\r\n\r\n        <!-- \u{1F6E0} Reminder -->\r\n        <div class="notif-card reminder">\r\n            <ion-icon name="alert-circle-outline" class="notif-icon"></ion-icon>\r\n            <div class="notif-details">\r\n                <h3>Oil Change Reminder</h3>\r\n                <p>Your last oil change was 3 months ago. It\u2019s time for a new one!</p>\r\n                <div class="notif-meta">\r\n                    <span class="badge reminder-badge">Reminder</span>\r\n                    <span class="time">2h ago</span>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        <!-- \u2705 Completed -->\r\n        <div class="notif-card completed">\r\n            <ion-icon name="checkmark-done-circle-outline" class="notif-icon"></ion-icon>\r\n            <div class="notif-details">\r\n                <h3>Bike Wash Completed</h3>\r\n                <p>Your booking for Bike Wash has been completed successfully.</p>\r\n                <div class="notif-meta">\r\n                    <span class="badge completed-badge">Completed</span>\r\n                    <span class="time">Yesterday</span>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        <!-- \u{1F381} Offer -->\r\n        <div class="notif-card offer">\r\n            <ion-icon name="gift-outline" class="notif-icon"></ion-icon>\r\n            <div class="notif-details">\r\n                <h3>Special Discount!</h3>\r\n                <p>Get 20% off on your next service booking this week.</p>\r\n                <div class="notif-meta">\r\n                    <span class="badge offer-badge">Offer</span>\r\n                    <span class="time">1 day ago</span>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n\r\n</ion-content>', styles: ["/* src/app/pages/user/user-notification/user-notification.scss */\n.notif-page {\n  --background:\n    linear-gradient(\n      180deg,\n      #f5f7fa,\n      #fff);\n  padding: 12px;\n}\n.notif-page .notif-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 12px;\n  position: sticky;\n  top: 0;\n  background: white;\n  z-index: 10;\n  padding: 10px;\n  border-radius: 10px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);\n}\n.notif-page .notif-header ion-icon {\n  font-size: 24px;\n  color: #007aff;\n}\n.notif-page .notif-list {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  animation: fadeIn 0.6s ease;\n}\n.notif-page .notif-card {\n  display: flex;\n  gap: 10px;\n  padding: 14px;\n  background: #fff;\n  border-radius: 16px;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);\n  transition: transform 0.2s ease, box-shadow 0.2s ease;\n}\n.notif-page .notif-card:hover {\n  transform: scale(1.02);\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);\n}\n.notif-page .notif-card .notif-icon {\n  font-size: 28px;\n  align-self: center;\n}\n.notif-page .notif-card .notif-details h3 {\n  font-size: 16px;\n  font-weight: 600;\n}\n.notif-page .notif-card .notif-details p {\n  font-size: 13px;\n  color: #555;\n  margin: 4px 0;\n}\n.notif-page .notif-card .notif-details .notif-meta {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 12px;\n  margin-top: 4px;\n}\n.notif-page .notif-card .notif-details .notif-meta .badge {\n  padding: 4px 8px;\n  border-radius: 10px;\n  font-weight: 500;\n}\n.notif-page .notif-card.reminder .notif-icon {\n  color: #ff9f43;\n}\n.notif-page .notif-card.reminder .reminder-badge {\n  background: #ffe8c2;\n  color: #b65c00;\n}\n.notif-page .notif-card.completed .notif-icon {\n  color: #2ecc71;\n}\n.notif-page .notif-card.completed .completed-badge {\n  background: #d3f9d8;\n  color: #116530;\n}\n.notif-page .notif-card.offer .notif-icon {\n  color: #e84393;\n}\n.notif-page .notif-card.offer .offer-badge {\n  background: #ffd6e8;\n  color: #9b0955;\n}\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=user-notification.css.map */\n"] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(UserNotification, { className: "UserNotification", filePath: "src/app/pages/user/user-notification/user-notification.ts", lineNumber: 11 });
})();
export {
  UserNotification
};
//# sourceMappingURL=user-notification-S4UHWXF7.js.map
