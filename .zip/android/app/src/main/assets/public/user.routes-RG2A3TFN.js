import {
  calendar,
  calendarOutline,
  hammer,
  informationCircle,
  location,
  logOutOutline,
  notifications,
  people
} from "./chunk-TD74DZFV.js";
import {
  AlertController,
  IonIcon,
  IonLabel,
  IonTabBar,
  IonTabButton,
  IonTabs
} from "./chunk-OIW4YKS2.js";
import {
  Router,
  RouterModule
} from "./chunk-YNRRQX7A.js";
import {
  Component,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵtext
} from "./chunk-NPNYO6CD.js";
import "./chunk-SNP25XOO.js";
import "./chunk-T5LCTCQ6.js";
import {
  addIcons
} from "./chunk-6YQTY6DY.js";
import "./chunk-4DFKN73H.js";
import "./chunk-Y432OPTZ.js";
import "./chunk-ZRSBY7CA.js";
import "./chunk-APLECGL3.js";
import "./chunk-WA2EE23F.js";
import "./chunk-7GPIVXJN.js";
import "./chunk-CEAAMTO4.js";
import "./chunk-256GWCFY.js";
import "./chunk-5EU4VLVR.js";
import "./chunk-GZ5BDCOT.js";
import "./chunk-HUY7ESWV.js";
import "./chunk-GXFEW35R.js";
import {
  __async
} from "./chunk-EAE2VPRF.js";

// src/app/pages/tabs-page/tabs-page.ts
var _TabsPage = class _TabsPage {
  constructor(router, alertCtrl) {
    this.router = router;
    this.alertCtrl = alertCtrl;
    addIcons({ calendar, people, location, notifications, informationCircle, hammer, calendarOutline, logOutOutline });
  }
  logout() {
    return __async(this, null, function* () {
      const alert = yield this.alertCtrl.create({
        header: "Logout",
        message: "Are you sure you want to log out?",
        buttons: [
          {
            text: "Cancel",
            role: "cancel"
          },
          {
            text: "Yes, Logout",
            handler: () => {
              localStorage.clear();
              this.router.navigateByUrl("/login", { replaceUrl: true });
            }
          }
        ]
      });
      yield alert.present();
    });
  }
};
_TabsPage.\u0275fac = function TabsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TabsPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(AlertController));
};
_TabsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _TabsPage, selectors: [["ng-component"]], decls: 22, vars: 0, consts: [["slot", "bottom"], ["tab", "store"], ["name", "location"], ["tab", "service"], ["name", "hammer"], ["tab", "mybooking"], ["name", "calendar-outline"], ["tab", "user-notification"], ["name", "notifications", 1, "notif-icon"], [3, "click"], ["name", "log-out-outline", 1, "logout-icon"]], template: function TabsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-tabs")(1, "ion-tab-bar", 0)(2, "ion-tab-button", 1);
    \u0275\u0275element(3, "ion-icon", 2);
    \u0275\u0275elementStart(4, "ion-label");
    \u0275\u0275text(5, "Store");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "ion-tab-button", 3);
    \u0275\u0275element(7, "ion-icon", 4);
    \u0275\u0275elementStart(8, "ion-label");
    \u0275\u0275text(9, "Service");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "ion-tab-button", 5);
    \u0275\u0275element(11, "ion-icon", 6);
    \u0275\u0275elementStart(12, "ion-label");
    \u0275\u0275text(13, "My Booking");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "ion-tab-button", 7);
    \u0275\u0275element(15, "ion-icon", 8);
    \u0275\u0275elementStart(16, "ion-label");
    \u0275\u0275text(17, "Notification");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "ion-tab-button", 9);
    \u0275\u0275listener("click", function TabsPage_Template_ion_tab_button_click_18_listener() {
      return ctx.logout();
    });
    \u0275\u0275element(19, "ion-icon", 10);
    \u0275\u0275elementStart(20, "ion-label");
    \u0275\u0275text(21, "Logout");
    \u0275\u0275elementEnd()()()();
  }
}, dependencies: [
  IonTabs,
  IonTabBar,
  IonTabButton,
  IonIcon,
  IonLabel,
  RouterModule
], encapsulation: 2 });
var TabsPage = _TabsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabsPage, [{
    type: Component,
    args: [{ imports: [
      IonTabs,
      IonTabBar,
      IonTabButton,
      IonIcon,
      IonLabel,
      RouterModule
    ], template: '<ion-tabs>\n  <ion-tab-bar slot="bottom">\n    <!-- <ion-tab-button tab="schedule">\n      <ion-icon name="calendar"></ion-icon>\n      <ion-label>Schedule</ion-label>\n    </ion-tab-button> -->\n\n    <!-- <ion-tab-button tab="speakers">\n      <ion-icon name="people"></ion-icon>\n      <ion-label>Speakers</ion-label>\n    </ion-tab-button> -->\n\n    <!-- <ion-tab-button tab="map">\n      <ion-icon name="location"></ion-icon>\n      <ion-label>Map</ion-label>\n    </ion-tab-button> -->\n\n\n    <!-- <ion-tab-button tab="about">\n      <ion-icon name="information-circle"></ion-icon>\n      <ion-label>About</ion-label>\n    </ion-tab-button> -->\n\n    <ion-tab-button tab="store">\n      <ion-icon name="location"></ion-icon>\n      <ion-label>Store</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab="service">\n      <ion-icon name="hammer"></ion-icon>\n      <ion-label>Service</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab="mybooking">\n      <ion-icon name="calendar-outline"></ion-icon>\n      <ion-label>My Booking</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab="user-notification">\n      <ion-icon name="notifications" class="notif-icon"></ion-icon>\n      <ion-label>Notification</ion-label>\n    </ion-tab-button>\n    <ion-tab-button (click)="logout()">\n      <ion-icon name="log-out-outline" class="logout-icon"></ion-icon>\n      <ion-label>Logout</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>' }]
  }], () => [{ type: Router }, { type: AlertController }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(TabsPage, { className: "TabsPage", filePath: "src/app/pages/tabs-page/tabs-page.ts", lineNumber: 25 });
})();

// src/app/pages/user/user.routes.ts
var USER_ROUTES = [
  {
    path: "",
    component: TabsPage,
    children: [
      // 🏬 Store Page — Default First
      {
        path: "store",
        loadComponent: () => import("./store-details-OHMXQBQN.js").then((m) => m.StoreDetails)
      },
      // 🧾 Service Page
      {
        path: "service",
        loadComponent: () => import("./service-details-7WVV724M.js").then((m) => m.ServiceDetails)
      },
      // 📅 My Booking Page
      {
        path: "mybooking",
        loadComponent: () => import("./mybooking-details-YIXZB2LJ.js").then((m) => m.MybookingDetails)
      },
      // 🔔 Notification Page
      {
        path: "user-notification",
        loadComponent: () => import("./user-notification-S4UHWXF7.js").then((m) => m.UserNotification)
      },
      // 👉 Default Redirect (Load Store First)
      {
        path: "",
        redirectTo: "store",
        pathMatch: "full"
      }
    ]
  }
];
export {
  USER_ROUTES
};
//# sourceMappingURL=user.routes-RG2A3TFN.js.map
