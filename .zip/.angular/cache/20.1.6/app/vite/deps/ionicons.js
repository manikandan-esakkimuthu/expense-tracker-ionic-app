import {
  addIcons,
  setAssetPath
} from "./chunk-QHGSX5CA.js";
import "./chunk-EAE2VPRF.js";
export {
  addIcons,
  setAssetPath
};
