import {
  WebPlugin
} from "./chunk-LG4A2HCZ.js";
import {
  __async
} from "./chunk-EAE2VPRF.js";

// node_modules/@capacitor/splash-screen/dist/esm/web.js
var SplashScreenWeb = class extends WebPlugin {
  show(_options) {
    return __async(this, null, function* () {
      return void 0;
    });
  }
  hide(_options) {
    return __async(this, null, function* () {
      return void 0;
    });
  }
};
export {
  SplashScreenWeb
};
//# sourceMappingURL=web-E3RNVH43.js.map
